package com.pulseoftheforsaken.simplelogger;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWImage;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.io.IOException;

public class CursorEffect {
    private static final ResourceLocation CURSOR_EYE = new ResourceLocation("pulseoftheforsaken", "assets/cursor_eye.png");
    private static boolean isCustomCursor = false;
    private static long customCursor = 0;

    public static void update() {
        Minecraft mc = Minecraft.getInstance();
        long window = mc.getWindow().getWindow();
        if (PsycheManager.getPsyche() < 50) {
            if (!isCustomCursor) {
                setCustomCursor(window);
                isCustomCursor = true;
            }
        } else {
            if (isCustomCursor) {
                GLFW.glfwSetCursor(window, 0); // Przywróć domyślny kursor
                isCustomCursor = false;
            }
        }
    }

    private static void setCustomCursor(long window) {
        Minecraft mc = Minecraft.getInstance();
        try {
            NativeImage image = NativeImage.read(mc.getResourceManager().open(CURSOR_EYE));
            GLFWImage glfwImage = GLFWImage.malloc();
            int[] pixels = image.getPixelsRGBA();
            ByteBuffer buffer = ByteBuffer.allocateDirect(pixels.length * 4).order(ByteOrder.nativeOrder());
            for (int pixel : pixels) {
                buffer.putInt(pixel);
            }
            buffer.flip();
            glfwImage.set(image.getWidth(), image.getHeight(), buffer);
            if (customCursor != 0) {
                GLFW.glfwDestroyCursor(customCursor);
            }
            customCursor = GLFW.glfwCreateCursor(glfwImage, image.getWidth() / 2, image.getHeight() / 2);
            GLFW.glfwSetCursor(window, customCursor);
            glfwImage.free();
            image.close();
        } catch (Exception e) {
            // Jeśli nie uda się ustawić kursora, zignoruj
        }
    }
} 