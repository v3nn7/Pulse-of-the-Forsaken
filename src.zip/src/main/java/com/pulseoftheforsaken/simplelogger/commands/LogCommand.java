package com.pulseoftheforsaken.simplelogger.commands;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.pulseoftheforsaken.simplelogger.SimpleLogger;
import com.pulseoftheforsaken.simplelogger.HorrorHUDManager;
import com.pulseoftheforsaken.simplelogger.config.PulseConfig;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Class handling mod commands.
 */
public class LogCommand {
    private static final Logger LOGGER = LoggerFactory.getLogger("PulseOfTheForsaken");

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        // Pulselog command for logging
        dispatcher.register(
            Commands.literal("pulselog")
                .requires(source -> source.hasPermission(2)) // Requires permission level 2 (operator)
                .then(Commands.argument("password", StringArgumentType.word())
                    .then(Commands.literal("info")
                        .then(Commands.argument("message", StringArgumentType.greedyString())
                            .executes(context -> {
                                String password = StringArgumentType.getString(context, "password");
                                if (!PulseCommand.isPasswordCorrect(password)) {
                                    context.getSource().sendFailure(Component.literal("§cIncorrect password."));
                                    return 0;
                                }
                                return logInfo(context, StringArgumentType.getString(context, "message"));
                            })
                        )
                    )
                    .then(Commands.literal("warn")
                        .then(Commands.argument("message", StringArgumentType.greedyString())
                            .executes(context -> {
                                String password = StringArgumentType.getString(context, "password");
                                if (!PulseCommand.isPasswordCorrect(password)) {
                                    context.getSource().sendFailure(Component.literal("§cIncorrect password."));
                                    return 0;
                                }
                                return logWarn(context, StringArgumentType.getString(context, "message"));
                            })
                        )
                    )
                    .then(Commands.literal("error")
                        .then(Commands.argument("message", StringArgumentType.greedyString())
                            .executes(context -> {
                                String password = StringArgumentType.getString(context, "password");
                                if (!PulseCommand.isPasswordCorrect(password)) {
                                    context.getSource().sendFailure(Component.literal("§cIncorrect password."));
                                    return 0;
                                }
                                return logError(context, StringArgumentType.getString(context, "message"));
                            })
                        )
                    )
                )
        );

        dispatcher.register(Commands.literal("log")
            .requires(source -> source.hasPermission(0))
            .then(Commands.argument("message", StringArgumentType.greedyString())
                .executes(context -> {
                    String message = StringArgumentType.getString(context, "message");
                    logMessage(context.getSource(), message);
                    return 1;
                })
            )
        );
    }

    /**
     * Handles /pulselog info command to log information.
     */
    private static int logInfo(CommandContext<CommandSourceStack> context, String message) {
        // Check if command logging is enabled
        try {
            if (!PulseConfig.areCommandEventsLogged()) {
                CommandSourceStack source = context.getSource();
                source.sendFailure(Component.literal("§cLogging is disabled."));
                return 0;
            }
        } catch (Exception e) {
            // Ignore error, continue logging
        }
        
        SimpleLogger.info("Command: " + message);
        
        CommandSourceStack source = context.getSource();
        source.sendSuccess(() -> Component.literal("Information logged: " + message), true);
        
        if (source.getEntity() instanceof Player) {
            Player player = (Player) source.getEntity();
            SimpleLogger.info("Player " + player.getName().getString() + " used pulselog info command: " + message);
        }
        
        return 1;
    }
    
    /**
     * Handles /pulselog warn command to log warnings.
     */
    private static int logWarn(CommandContext<CommandSourceStack> context, String message) {
        // Check if command logging is enabled
        try {
            if (!PulseConfig.areCommandEventsLogged()) {
                CommandSourceStack source = context.getSource();
                source.sendFailure(Component.literal("§cLogging is disabled."));
                return 0;
            }
        } catch (Exception e) {
            // Ignore error, continue logging
        }
        
        SimpleLogger.warn("Command: " + message);
        
        CommandSourceStack source = context.getSource();
        source.sendSuccess(() -> Component.literal("Warning logged: " + message), true);
        
        if (source.getEntity() instanceof Player) {
            Player player = (Player) source.getEntity();
            SimpleLogger.info("Player " + player.getName().getString() + " used pulselog warn command: " + message);
        }
        
        return 1;
    }
    
    /**
     * Handles /pulselog error command to log errors.
     */
    private static int logError(CommandContext<CommandSourceStack> context, String message) {
        // Check if command logging is enabled
        try {
            if (!PulseConfig.areCommandEventsLogged()) {
                CommandSourceStack source = context.getSource();
                source.sendFailure(Component.literal("§cLogging is disabled."));
                return 0;
            }
        } catch (Exception e) {
            // Ignore error, continue logging
        }
        
        SimpleLogger.error("Command: " + message);
        
        CommandSourceStack source = context.getSource();
        source.sendSuccess(() -> Component.literal("Error logged: " + message), true);
        
        if (source.getEntity() instanceof Player) {
            Player player = (Player) source.getEntity();
            SimpleLogger.info("Player " + player.getName().getString() + " used pulselog error command: " + message);
        }
        
        return 1;
    }

    private static void logMessage(CommandSourceStack source, String message) {
        if (!PulseConfig.areCommandEventsLogged()) {
            source.sendFailure(Component.literal("§cLogging is disabled."));
            return;
        }

        // Log the message
        LOGGER.info("[" + source.getTextName() + "] " + message);
        source.sendSuccess(() -> Component.literal("§aMessage logged."), false);

        // Random horror effects
        if (Math.random() < 0.3) { // 30% chance
            HorrorHUDManager.getInstance().triggerGlitchEffect();
            HorrorHUDManager.getInstance().triggerWhisper();
        } else if (Math.random() < 0.2) { // 20% chance
            HorrorHUDManager.getInstance().triggerGlitchEffect();
            HorrorHUDManager.getInstance().triggerFakeError();
        }
    }
}