package com.pulseoftheforsaken.simplelogger.commands;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.pulseoftheforsaken.simplelogger.HorrorHUDManager;
import com.pulseoftheforsaken.simplelogger.PlayerDataRevealManager;
import com.pulseoftheforsaken.simplelogger.ui.PulseHUD;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.network.FriendlyByteBuf;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.pulseoftheforsaken.simplelogger.config.PulseConfig;

/**
 * Class handling Pulse of the Forsaken mod commands.
 */
public class PulseCommand {
    private static final Logger LOGGER = LoggerFactory.getLogger("PulseOfTheForsaken");
    private static final String COMMAND_PASSWORD = "1141";

    /**
     * Registers mod commands.
     */
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("pulse")
            .requires(source -> source.hasPermission(0))
            .then(Commands.literal("toggle")
                .executes(context -> {
                    CommandSourceStack source = context.getSource();
                    if (source.getEntity() instanceof ServerPlayer) {
                        ServerPlayer player = (ServerPlayer) source.getEntity();
                        if (HorrorHUDManager.getInstance().isEnabled()) {
                            HorrorHUDManager.getInstance().disable();
                            source.sendSuccess(() -> Component.literal("Horror effects disabled."), false);
                        } else {
                            HorrorHUDManager.getInstance().enable();
                            source.sendSuccess(() -> Component.literal("Horror effects enabled."), false);
                        }
                    }
                    return 1;
                }))
            .then(Commands.literal("gui")
                .executes(context -> {
                    CommandSourceStack source = context.getSource();
                    if (source.getEntity() instanceof ServerPlayer) {
                        ServerPlayer player = (ServerPlayer) source.getEntity();
                        player.openMenu(new PulseHUD());
                    }
                    return 1;
                }))
            .then(Commands.literal("dev")
                .then(Commands.argument("action", StringArgumentType.word())
                    .then(Commands.argument("password", StringArgumentType.word())
                        .executes(context -> {
                            String action = StringArgumentType.getString(context, "action");
                            String password = StringArgumentType.getString(context, "password");
                            if (!password.equals("1043")) {
                                context.getSource().sendFailure(Component.literal("§cIncorrect developer password."));
                                return 0;
                            }
                            switch (action) {
                                case "jumpscare":
                                    HorrorHUDManager.triggerJumpscare();
                                    context.getSource().sendSuccess(() -> Component.literal("§aJumpscare triggered!"), false);
                                    break;
                                case "entity":
                                    // TODO: Implementacja pojawienia się postaci za graczem
                                    context.getSource().sendSuccess(() -> Component.literal("§aEntity behind player triggered! (TODO)"), false);
                                    break;
                                case "glitch":
                                    HorrorHUDManager.triggerGlitchEffect();
                                    context.getSource().sendSuccess(() -> Component.literal("§aGlitch effect triggered!"), false);
                                    break;
                                default:
                                    context.getSource().sendFailure(Component.literal("§cUnknown dev action."));
                                    return 0;
                            }
                            return 1;
                        })
                    )
                )
            )
            .then(Commands.argument("password", StringArgumentType.word())
                .executes(context -> {
                    String password = StringArgumentType.getString(context, "password");
                    if (!password.equals(COMMAND_PASSWORD)) {
                        context.getSource().sendFailure(Component.literal("§cIncorrect password."));
                        return 0;
                    }
                    return showHelp(context.getSource());
                })
                .then(Commands.literal("stopcam")
                    .executes(context -> {
                        String password = StringArgumentType.getString(context, "password");
                        if (!password.equals(COMMAND_PASSWORD)) {
                            context.getSource().sendFailure(Component.literal("§cIncorrect password."));
                            return 0;
                        }
                        return stopCam(context.getSource());
                    })
                )
                .then(Commands.literal("help")
                    .executes(context -> {
                        String password = StringArgumentType.getString(context, "password");
                        if (!password.equals(COMMAND_PASSWORD)) {
                            context.getSource().sendFailure(Component.literal("§cIncorrect password."));
                            return 0;
                        }
                        return showHelp(context.getSource());
                    })
                )
                .then(Commands.literal("status")
                    .executes(context -> {
                        String password = StringArgumentType.getString(context, "password");
                        if (!password.equals(COMMAND_PASSWORD)) {
                            context.getSource().sendFailure(Component.literal("§cIncorrect password."));
                            return 0;
                        }
                        return showStatus(context.getSource());
                    })
                )
                .then(Commands.literal("reset")
                    .requires(source -> source.hasPermission(2))
                    .executes(context -> {
                        String password = StringArgumentType.getString(context, "password");
                        if (!password.equals(COMMAND_PASSWORD)) {
                            context.getSource().sendFailure(Component.literal("§cIncorrect password."));
                            return 0;
                        }
                        return resetMod(context.getSource());
                    })
                )
            )
            .executes(context -> {
                CommandSourceStack source = context.getSource();
                source.sendSuccess(() -> Component.literal(
                    "Available commands:\n" +
                    "/pulse status - Show mod status\n" +
                    "/pulse toggle - Enable/disable horror effects\n" +
                    "/pulse reset - Reset the mod\n" +
                    "/pulse gui - Open the mod interface"
                ), false);
                return 1;
            })
        );
        // Osobna komenda do resetowania zgody
        dispatcher.register(Commands.literal("pulseconsent")
            .requires(source -> source.hasPermission(0))
            .executes(context -> {
                PulseConfig.COMMON.acceptedConsent.set(false);
                PulseConfig.COMMON_SPEC.save();
                context.getSource().sendSuccess(() -> Component.literal("Consent reset. Please restart the game to see the consent screen again."), false);
                return 1;
            })
        );
    }

    /**
     * Handles /pulse stopcam command to disable monitoring.
     */
    private static int stopCam(CommandSourceStack source) {
        // Disable HUD effects
        HorrorHUDManager.getInstance().disable();
        
        source.sendSuccess(() -> Component.literal("§aHUD effects disabled."), true);
        LOGGER.info("HUD effects were disabled by " + source.getTextName());
        
        if (source.getEntity() instanceof Player player) {
            // Update log
            LOGGER.info("HUD effects were disabled by " + player.getName().getString());
        }
        
        return 1;
    }
    
    /**
     * Handles /pulse help command to display help.
     */
    private static int showHelp(CommandSourceStack source) {
        source.sendSuccess(() -> Component.literal("§6=== Pulse of the Forsaken - Help ==="), false);
        source.sendSuccess(() -> Component.literal("§7/pulse <password> stopcam - Disable local monitoring and HUD effects"), false);
        source.sendSuccess(() -> Component.literal("§7/pulse <password> status - Show mod status"), false);
        source.sendSuccess(() -> Component.literal("§7/pulse <password> help - Show this help"), false);
        
        if (source.hasPermission(2)) {
            source.sendSuccess(() -> Component.literal("§7/pulse <password> reset - Reset mod (operators only)"), false);
        }
        
        return 1;
    }
    
    /**
     * Handles /pulse status command to display mod status.
     */
    private static int showStatus(CommandSourceStack source) {
        source.sendSuccess(() -> Component.literal("§6=== Pulse of the Forsaken - Status ==="), false);
        source.sendSuccess(() -> Component.literal("§7Horror HUD: " + (HorrorHUDManager.getInstance().isEnabled() ? "§aEnabled" : "§cDisabled")), false);
        
        if (source.getEntity() instanceof Player) {
            Player player = (Player) source.getEntity();
            source.sendSuccess(() -> Component.literal("§7Player: " + player.getName().getString()), false);
        }
        
        return 1;
    }
    
    /**
     * Handles /pulse reset command to reset the mod.
     */
    private static int resetMod(CommandSourceStack source) {
        // Disable all effects
        HorrorHUDManager.getInstance().disable();
        
        source.sendSuccess(() -> Component.literal("§aMod has been reset."), true);
        LOGGER.info("Mod was reset by " + source.getTextName());
        
        return 1;
    }
    
    /**
     * Checks if the provided password is correct.
     */
    public static boolean isPasswordCorrect(String password) {
        return COMMAND_PASSWORD.equals(password);
    }
    

}
