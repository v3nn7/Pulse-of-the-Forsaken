package com.pulseoftheforsaken.simplelogger.effects;

import com.pulseoftheforsaken.simplelogger.PulseOfTheForsakenMod;
import net.minecraft.client.resources.sounds.AbstractSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;

public class HeartbeatSound extends AbstractSoundInstance {
    private static final ResourceLocation SOUND_LOCATION = new ResourceLocation(PulseOfTheForsakenMod.MOD_ID, "heartbeat");
    private int tickCount = 0;
    private float initialPitch;

    public HeartbeatSound(Player player) {
        super(SOUND_LOCATION, SoundSource.MUSIC, SoundInstance.createUnseededRandom());
        this.volume = 1.0F;
        this.pitch = 1.0F;
        this.initialPitch = 1.0F;
        this.looping = true;
        this.delay = 0;
        this.x = (float) player.getX();
        this.y = (float) player.getY();
        this.z = (float) player.getZ();
        this.relative = true;
    }

    /**
     * Aktualizuje dźwięk, zwiększając pitch co 20 ticków
     */
    public void tick() {
        tickCount++;
        if (tickCount % 20 == 0 && pitch < 2.0F) {
            pitch += 0.1F;
        }
    }

    /**
     * Resetuje pitch do wartości początkowej
     */
    public void resetPitch() {
        pitch = initialPitch;
    }
} 