package com.pulseoftheforsaken.simplelogger;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * Klasa obsługująca efekt lustrzanego odbicia świata
 */
public class MirrorWorldEffect {
    private static final RandomSource random = RandomSource.create();
    private static boolean isMirrorActive = false;
    private static int mirrorDuration = 0;
    private static final int MIRROR_DURATION = 400; // 20 sekund (20 ticków/s)
    
    /**
     * Aktywuje efekt lustrzanego odbicia
     */
    public static void activateMirrorEffect() {
        isMirrorActive = true;
        mirrorDuration = MIRROR_DURATION;
        
        // Wyświetl wiadomość
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player != null) {
            minecraft.player.displayClientMessage(Component.literal("§c§oThe world feels... different..."), true);
        }
    }
    
    /**
     * Aktualizuje stan efektu lustrzanego odbicia
     */
    public static void update() {
        if (!isMirrorActive) return;
        
        mirrorDuration--;
        
        // Co 5 sekund wyświetl wiadomość
        if (mirrorDuration % 100 == 0) {
            Minecraft minecraft = Minecraft.getInstance();
            if (minecraft.player != null) {
                String[] messages = {
                    "§c§oEverything is backwards...",
                    "§c§oThe world is mirrored...",
                    "§c§oLeft is right, right is left...",
                    "§c§oThe reflection is wrong...",
                    "§c§oThe world is not as it seems..."
                };
                String message = messages[random.nextInt(messages.length)];
                minecraft.player.displayClientMessage(Component.literal(message), true);
            }
        }
        
        // Zakończ efekt
        if (mirrorDuration <= 0) {
            isMirrorActive = false;
            
            // Wyświetl końcową wiadomość
            Minecraft minecraft = Minecraft.getInstance();
            if (minecraft.player != null) {
                minecraft.player.displayClientMessage(Component.literal("§c§oThe world returns to normal..."), true);
            }
        }
    }
    
    /**
     * Sprawdza, czy efekt lustrzanego odbicia jest aktywny
     */
    public static boolean isMirrorActive() {
        return isMirrorActive;
    }
    
    /**
     * Renderuje lustrzane odbicie HUD
     */
    @SubscribeEvent
    public static void onRenderOverlay(RenderGuiOverlayEvent.Post event) {
        if (!isMirrorActive) return;
        
        GuiGraphics guiGraphics = event.getGuiGraphics();
        int width = guiGraphics.guiWidth();
        int height = guiGraphics.guiHeight();
        
        // Lustrzane odbicie całego ekranu
        guiGraphics.pose().pushPose();
        guiGraphics.pose().translate(width, 0, 0);
        guiGraphics.pose().scale(-1, 1, 1);
        
        // Renderuj HUD
        // TODO: Dodaj renderowanie lustrzanego HUD
        
        guiGraphics.pose().popPose();
    }
} 