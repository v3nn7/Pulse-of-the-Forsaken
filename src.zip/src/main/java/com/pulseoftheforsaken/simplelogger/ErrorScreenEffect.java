package com.pulseoftheforsaken.simplelogger;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;

public class ErrorScreenEffect {
    private static final int DURATION = 60; // 3 sekundy
    private static final ResourceLocation ERROR_SCREEN = new ResourceLocation("pulseoftheforsaken", "assets/error_screen_01.png");
    private static boolean active = false;
    private static int timer = 0;

    public static void activate() {
        active = true;
        timer = DURATION;
        // Odtwórz dźwięk błędu
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            mc.player.playSound(
                SoundEvent.createVariableRangeEvent(
                    new ResourceLocation("pulseoftheforsaken", "disconnect_fail")
                ),
                1.0F, 1.0F
            );
        }
    }

    public static void update() {
        if (!active) return;
        timer--;
        if (timer <= 0) {
            active = false;
        }
    }

    public static void onRenderOverlay(GuiGraphics guiGraphics) {
        if (!active) return;
        int width = guiGraphics.guiWidth();
        int height = guiGraphics.guiHeight();
        guiGraphics.blit(ERROR_SCREEN, 0, 0, 0, 0, width, height, width, height);
    }

    public static boolean isActive() {
        return active;
    }
} 