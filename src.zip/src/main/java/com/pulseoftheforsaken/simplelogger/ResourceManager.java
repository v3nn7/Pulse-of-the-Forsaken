package com.pulseoftheforsaken.simplelogger;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class ResourceManager {
    private static ResourceManager instance;
    private final Map<String, DynamicTexture> textureCache = new HashMap<>();
    private static final String MOD_ID = "pulseoftheforsaken";
    
    // Rejestr dźwięków
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, MOD_ID);
    public static final RegistryObject<SoundEvent> JUMPSCARE_SOUND = SOUNDS.register("jumpscare",
        () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(MOD_ID, "jumpscare")));
    
    // Tekstury jumpscare'ów
    public static final ResourceLocation JUMPSCARE_1 = new ResourceLocation(MOD_ID, "assets/gui/jumpscare1.png");
    public static final ResourceLocation JUMPSCARE_2 = new ResourceLocation(MOD_ID, "assets/gui/jumpscare2.png");
    
    // Tekstura skórki entity2137
    public static final ResourceLocation ENTITY_2137_SKIN = new ResourceLocation(MOD_ID, "assets/entity/entity2137_skin.png");
    
    private ResourceManager() {}
    
    public static ResourceManager getInstance() {
        if (instance == null) {
            instance = new ResourceManager();
        }
        return instance;
    }
    
    public void loadTexture(String name, String path) {
        try (InputStream is = getClass().getResourceAsStream(path)) {
            if (is == null) {
                System.err.println("Nie można znaleźć tekstury: " + path);
                return;
            }
            
            BufferedImage image = ImageIO.read(is);
            NativeImage nativeImage = new NativeImage(image.getWidth(), image.getHeight(), true);
            
            for (int y = 0; y < image.getHeight(); y++) {
                for (int x = 0; x < image.getWidth(); x++) {
                    int rgb = image.getRGB(x, y);
                    nativeImage.setPixelRGBA(x, y, rgb);
                }
            }
            
            DynamicTexture texture = new DynamicTexture(nativeImage);
            textureCache.put(name, texture);
            
        } catch (IOException e) {
            System.err.println("Błąd podczas ładowania tekstury: " + path);
            e.printStackTrace();
        }
    }
    
    public DynamicTexture getTexture(String name) {
        return textureCache.get(name);
    }
    
    public void playJumpscareSound() {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player != null) {
            minecraft.player.playSound(JUMPSCARE_SOUND.get(), 1.0F, 1.0F);
        }
    }
    
    public void reloadTextures() {
        textureCache.clear();
        // Tutaj dodaj ponowne ładowanie tekstur
    }
} 