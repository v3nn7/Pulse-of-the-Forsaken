package com.pulseoftheforsaken.simplelogger;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;

public class SignWhisperEffect {
    private static final int DURATION = 100; // 5 sekund
    private static final ResourceLocation SIGN_TEXTURE = new ResourceLocation("pulseoftheforsaken", "assets/sign_message_hidden.png");
    private static boolean active = false;
    private static int timer = 0;

    public static void activate() {
        active = true;
        timer = DURATION;
        // Odtwórz ambient whisper
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            mc.player.playSound(
                SoundEvent.createVariableRangeEvent(
                    new ResourceLocation("pulseoftheforsaken", "whisper_loop")
                ),
                1.0F, 1.0F
            );
        }
    }

    public static void update() {
        if (!active) return;
        timer--;
        if (timer <= 0) {
            active = false;
        }
    }

    public static void onRenderOverlay(GuiGraphics guiGraphics) {
        if (!active) return;
        int width = guiGraphics.guiWidth();
        int height = guiGraphics.guiHeight();
        guiGraphics.blit(SIGN_TEXTURE, width / 2 - 128, height / 2 - 64, 0, 0, 256, 128, 256, 128);
    }

    public static boolean isActive() {
        return active;
    }
} 