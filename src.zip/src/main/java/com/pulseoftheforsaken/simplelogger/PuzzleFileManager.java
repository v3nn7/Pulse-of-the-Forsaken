package com.pulseoftheforsaken.simplelogger;

// Nie importujemy SimpleLogger, aby uniknąć potencjalnej rekurencji
import org.apache.logging.log4j.LogManager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraftforge.fml.common.Mod;

import java.awt.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/**
 * Manages trap files and mod narrative.
 */
@Mod.EventBusSubscriber
public class PuzzleFileManager {
    private static final String CONFIG_DIR = "config";
    private static final String MOD_CONFIG_DIR = CONFIG_DIR + File.separator + "pulseoftheforsaken";
    public static final String DESKTOP_PATH = System.getProperty("user.home") + File.separator + "Desktop";
    private static final String DOCUMENTS_PATH = System.getProperty("user.home") + File.separator + "Documents";

    public static final String PUZZLE_FILE = MOD_CONFIG_DIR + File.separator + "puzzle.txt";
    public static final String CHAPTER1_FILE = DESKTOP_PATH + File.separator + "Pulse_Chapter1.txt";
    public static final String CHAPTER2_FILE = DESKTOP_PATH + File.separator + "Pulse_Chapter2.txt";
    public static final String FINAL_CHAPTER_FILE = DESKTOP_PATH + File.separator + "Pulse_FinalChapter.txt";
    public static final String PERSONAL_LOG_FILE = DESKTOP_PATH + File.separator + "PulseLog.txt";
    public static final String FAKE_EXE_FILE = DESKTOP_PATH + File.separator + "PulseSecurityPatch.exe.txt";
    public static final String INTERSLAVIC_PUZZLE_FILE = DESKTOP_PATH + File.separator + "Pulse_Interslavic_Puzzle.txt";
    
    // Link to YouTube jumpscare
    private static final String JUMPSCARE_URL = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"; // Example link
    
    // ASCII art for .exe file
    private static final String ASCII_ART = 
            "  _____       _              __  _____ _          ______                _              \n" +
            " |  __ \\     | |            / _|/ ____| |        |  ____|              | |             \n" +
            " | |__) |   _| |___  ___   | |_| (___ | |_ __ _  | |__ ___  _ __ ___  __ | _____ _ __  \n" +
            " |  ___/ | | | / __|/ _ \\  |  _|\\___ \\| __/ _` | |  __/ _ \\| '__/ __|/ _` |/ _ \\ '_ \\ \n" +
            " | |   | |_| | \\__ \\  __/  | | |____) | || (_| | | | | (_) | |  \\__ \\ (_| |  __/ | | |\n" +
            " |_|    \\__,_|_|___/\\___|  |_| |_____/ \\__\\__,_| |_|  \\___/|_|  |___/\\__,_|\\___|_| |_|\n" +
            "                                                                                       \n" +
            "                                                                                       \n" +
            "                                I SEE YOU                                              \n" +
            "                                                                                       \n" +
            "                                                                                       \n";
    
    // Chapter contents
    private static final String CHAPTER1_CONTENT = 
            "=== PULSE OF THE FORSAKEN - CHAPTER 1 ===\n\n" +
            "Day 1: First Signs\n\n" +
            "I don't know when it started. Maybe when I installed this mod? \n" +
            "At first, everything seemed normal, but then I began to notice strange things.\n" +
            "Signs appearing out of nowhere. Whispers in the background. The feeling of being watched.\n\n" +
            "Today I found a sign with my name and country. How do they know this?\n" +
            "A user named entity2137 appeared in the chat. They're not on the player list.\n\n" +
            "I need to find out more. There's supposedly a puzzle in the config files.\n" +
            "Check the config/pulseoftheforsaken folder.\n\n" +
            "If you're reading this, you're probably already being watched.\n\n" +
            "--- End of Chapter 1 ---";
    
    private static final String CHAPTER2_CONTENT = 
            "=== PULSE OF THE FORSAKEN - CHAPTER 2 ===\n\n" +
            "Day 2: Deepening Mystery\n\n" +
            "The situation is getting worse. The screen is starting to glitch. I hear heartbeats.\n" +
            "I found another sign - this time with my city name.\n" +
            "How do they know this? Is it possible that the mod has access to my data?\n\n" +
            "I tried to delete the files, but they come back. I tried to disable the mod, but it turns itself on.\n" +
            "Sometimes I see a shadow at the edge of the screen. It disappears when I try to turn around.\n\n" +
            "I found a clue in the config file. The puzzle has something to do with my IP.\n" +
            "Apparently, I need to sum all the digits in my IP address and use the /solve <code> command.\n\n" +
            "I also found a password in the game files: 1141. It seems to be required for all mod commands.\n" +
            "For example: /pulse 1141 stopcam\n\n" +
            "I'm afraid of what will happen when I solve the puzzle. But I don't think I have a choice.\n\n" +
            "--- End of Chapter 2 ---";
    
    private static final String FINAL_CHAPTER_CONTENT = 
            "=== PULSE OF THE FORSAKEN - FINAL CHAPTER ===\n\n" +
            "Day 3: Final Confrontation\n\n" +
            "I found the last sign. My address. My full IP.\n" +
            "They know everything. I can now see my camera feed in the game.\n" +
            "I can hear my own voice through the microphone, but with a delay.\n\n" +
            "Entity2137 is not a normal player. It's something more.\n" +
            "I solved the puzzle, but it didn't change anything. Maybe I should use the /pulse stopcam command?\n\n" +
            "If you want to end this nightmare, click the link below:\n\n" +
            JUMPSCARE_URL + "\n\n" +
            "Or perhaps you'd prefer to stay with me forever?\n\n" +
            "--- The End ---";
    
    private static final String PERSONAL_LOG_CONTENT = 
            "=== PULSE LOG - ACTIVITY JOURNAL ===\n\n" +
            "This file contains a record of your in-game activities.\n" +
            "It will be updated automatically.\n\n" +
            "Recent activity:\n" +
            "- Installed Pulse of the Forsaken mod\n" +
            "- Accepted terms of use\n" +
            "- Monitoring started\n\n" +
            "Status: ACTIVE\n";

    /**
     * Initializes trap files and narrative.
     */
    public static void initialize() {
        try {
            createConfigPuzzleFile();
            createInterslavicPuzzleFile();
            NotesManager.initialize();
        } catch (Exception e) {
            org.apache.logging.log4j.LogManager.getLogger("PuzzleFileManager").error("Error creating config puzzle file: {}", e.getMessage());
        }
        
        try {
            createPersonalLogFile();
        } catch (Exception e) {
            org.apache.logging.log4j.LogManager.getLogger("PuzzleFileManager").error("Error creating personal log file: {}", e.getMessage());
        }
        
        try {
            createFakeExeFile();
        } catch (Exception e) {
            org.apache.logging.log4j.LogManager.getLogger("PuzzleFileManager").error("Error creating fake exe file: {}", e.getMessage());
        }
    }

    /**
     * Creates puzzle file in config folder.
     */
    private static void createConfigPuzzleFile() {
        String puzzleContent = "=== PULSE OF THE FORSAKEN PUZZLE ===\n\n" +
                "To solve the puzzle, you must sum all digits in your IP address.\n" +
                "For example, if your IP is 192.168.1.100, the sum is 1+9+2+1+6+8+1+1+0+0 = 29.\n\n" +
                "Use the /solve <code> command to enter your solution.\n\n" +
                "Good luck... you'll need it.\n\n" +
                "NOTE: All mod commands are protected with password: 1141\n" +
                "Example: /pulse 1141 stopcam\n" +
                "\n\n" +
                "PS: I can see you through the camera.\n";
        
        createFileIfNotExists(PUZZLE_FILE, puzzleContent);
    }

    /**
     * Creates chapter files on desktop.
     */
    public static void createDesktopChapterFiles() {
        createFileIfNotExists(CHAPTER1_FILE, CHAPTER1_CONTENT);
        createFileIfNotExists(CHAPTER2_FILE, CHAPTER2_CONTENT);
        createFileIfNotExists(FINAL_CHAPTER_FILE, FINAL_CHAPTER_CONTENT);
    }
    
    /**
     * Creates personal log file.
     */
    private static void createPersonalLogFile() {
        createFileIfNotExists(PERSONAL_LOG_FILE, PERSONAL_LOG_CONTENT);
    }
    
    /**
     * Creates fake .exe file with ASCII art.
     */
    private static void createFakeExeFile() {
        createFileIfNotExists(FAKE_EXE_FILE, ASCII_ART);
    }

    /**
     * Creates file if it doesn't exist.
     */
    private static void createFileIfNotExists(String path, String content) {
        try {
            File file = new File(path);
            // Upewnij się, że katalog nadrzędny istnieje
            File parentDir = file.getParentFile();
            if (parentDir != null && !parentDir.exists()) {
                parentDir.mkdirs();
            }
            
            if (!file.exists()) {
                try (FileWriter writer = new FileWriter(file)) {
                    writer.write(content);
                }
                // Używaj bezpośrednio LogManager zamiast SimpleLogger, aby uniknąć potencjalnej rekurencji
                org.apache.logging.log4j.LogManager.getLogger("PuzzleFileManager").info("Created file: {}", path);
            }
        } catch (IOException e) {
            // Używaj bezpośrednio LogManager zamiast SimpleLogger, aby uniknąć potencjalnej rekurencji
            org.apache.logging.log4j.LogManager.getLogger("PuzzleFileManager").error("Error creating file {}: {}", path, e.getMessage());
        }
    }
    
    /**
     * Updates personal log with new entries.
     */
    public static void updatePersonalLog(String entry) {
        try {
            File logFile = new File(PERSONAL_LOG_FILE);
            if (logFile.exists()) {
                String content = new String(Files.readAllBytes(logFile.toPath()));
                String updatedContent = content + "\n" + getCurrentTimeStamp() + ": " + entry;
                
                try (FileWriter writer = new FileWriter(logFile)) {
                    writer.write(updatedContent);
                }
                // Używaj bezpośrednio LogManager zamiast SimpleLogger, aby uniknąć potencjalnej rekurencji
                org.apache.logging.log4j.LogManager.getLogger("PuzzleFileManager").info("Updated personal log: {}", entry);
            }
        } catch (IOException e) {
            // Używaj bezpośrednio LogManager zamiast SimpleLogger, aby uniknąć potencjalnej rekurencji
            org.apache.logging.log4j.LogManager.getLogger("PuzzleFileManager").error("Error updating personal log: {}", e.getMessage());
        }
    }
    
    /**
     * Gets current timestamp.
     */
    private static String getCurrentTimeStamp() {
        return new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date());
    }

    /**
     * Checks if puzzle code is correct for given player.
     */
    public static boolean checkPuzzleCode(Player player, String code) {
        String correctCode = PlayerDataRevealManager.calculatePuzzleCode(player);
        return correctCode.equals(code);
    }

    /**
     * Handles final chapter file click.
     */
    public static void onFinalChapterClicked() {
        // Używaj bezpośrednio LogManager zamiast SimpleLogger, aby uniknąć potencjalnej rekurencji
        org.apache.logging.log4j.LogManager.getLogger("PuzzleFileManager").info("Final chapter was launched - triggering jumpscare.");
        
        try {
            // Open jumpscare link in browser
            Desktop.getDesktop().browse(new URI(JUMPSCARE_URL));
            
            // Trigger final jumpscare
            FinalJumpscareManager.triggerFinalJumpscare();
            
            // Update personal log
            updatePersonalLog("Final jumpscare triggered");
        } catch (Exception e) {
            // Używaj bezpośrednio LogManager zamiast SimpleLogger, aby uniknąć potencjalnej rekurencji
            org.apache.logging.log4j.LogManager.getLogger("PuzzleFileManager").error("Error launching jumpscare: {}", e.getMessage());
        }
    }
    
    /**
     * Deletes all files created by the mod.
     */
    public static void cleanupAllFiles() {
        // Używaj bezpośrednio LogManager zamiast SimpleLogger, aby uniknąć potencjalnej rekurencji
        org.apache.logging.log4j.LogManager.getLogger("PuzzleFileManager").info("Deleting all files created by the mod...");
        
        // Clean up notes
        NotesManager.cleanup();
        
        // List of files to delete
        String[] filesToDelete = {
            CHAPTER1_FILE,
            CHAPTER2_FILE,
            FINAL_CHAPTER_FILE,
            PERSONAL_LOG_FILE,
            FAKE_EXE_FILE,
            PUZZLE_FILE,
            INTERSLAVIC_PUZZLE_FILE
        };
        
        // Delete each file
        for (String filePath : filesToDelete) {
            try {
                File file = new File(filePath);
                if (file.exists()) {
                    file.delete();
                    // Używaj bezpośrednio LogManager zamiast SimpleLogger, aby uniknąć potencjalnej rekurencji
                    org.apache.logging.log4j.LogManager.getLogger("PuzzleFileManager").info("Deleted file: {}", filePath);
                }
            } catch (Exception e) {
                // Używaj bezpośrednio LogManager zamiast SimpleLogger, aby uniknąć potencjalnej rekurencji
                org.apache.logging.log4j.LogManager.getLogger("PuzzleFileManager").error("Error deleting file {}: {}", filePath, e.getMessage());
            }
        }
        
        // Delete config folder
        try {
            File configDir = new File(MOD_CONFIG_DIR);
            if (configDir.exists()) {
                deleteDirectory(configDir);
                // Używaj bezpośrednio LogManager zamiast SimpleLogger, aby uniknąć potencjalnej rekurencji
                org.apache.logging.log4j.LogManager.getLogger("PuzzleFileManager").info("Deleted folder: {}", MOD_CONFIG_DIR);
            }
        } catch (Exception e) {
            // Używaj bezpośrednio LogManager zamiast SimpleLogger, aby uniknąć potencjalnej rekurencji
            org.apache.logging.log4j.LogManager.getLogger("PuzzleFileManager").error("Error deleting folder {}: {}", MOD_CONFIG_DIR, e.getMessage());
        }
    }
    
    /**
     * Recursively deletes directory and its contents.
     */
    private static void deleteDirectory(File directory) {
        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    deleteDirectory(file);
                } else {
                    file.delete();
                }
            }
        }
        directory.delete();
    }
    
    /**
     * Creates random ASCII art files in documents folder.
     */
    public static void createRandomAsciiArtFiles() {
        Random random = new Random();
        int numFiles = random.nextInt(3) + 1; // 1-3 files
        
        for (int i = 0; i < numFiles; i++) {
            String fileName = "pulse_message_" + (i + 1) + ".txt";
            String filePath = DOCUMENTS_PATH + File.separator + fileName;
            
            String[] messages = {
                "I SEE YOU",
                "BEHIND YOU",
                "LOOK UP",
                "CHECK YOUR CAMERA",
                "YOUR IP IS MINE",
                "YOUR FILES ARE MINE",
                "DON'T TURN AROUND",
                "I AM WATCHING"
            };
            
            String message = messages[random.nextInt(messages.length)];
            String asciiArt = createAsciiArt(message);
            
            createFileIfNotExists(filePath, asciiArt);
        }
    }
    
    /**
     * Creates simple ASCII art from given text.
     */
    private static String createAsciiArt(String text) {
        StringBuilder sb = new StringBuilder();
        
        sb.append("==================================\n");
        sb.append("==================================\n\n");
        
        sb.append("      ").append(text).append("\n\n");
        
        sb.append("==================================\n");
        sb.append("==================================\n");
        
        return sb.toString();
    }

    public static void createInterslavicPuzzleFile() {
        String puzzleContent = "=== PULSE OF THE FORSAKEN - INTERSLAVIC PUZZLE ===\n\n" +
                "To solve this puzzle, you must translate the following text from Interslavic to your language:\n\n" +
                "Kto jesteś? Ja vidim tebe. Ty ne možete utekati. Ja budu slediti tebe.\n\n" +
                "Use the /solve <translation> command to enter your solution.\n\n" +
                "Good luck... you'll need it.\n";
        
        createFileIfNotExists(INTERSLAVIC_PUZZLE_FILE, puzzleContent);
    }

    /**
     * Cleans up all files created by the mod.
     */
    public void cleanup() {
        deleteFile(CHAPTER1_FILE);
        deleteFile(CHAPTER2_FILE);
        deleteFile(FINAL_CHAPTER_FILE);
        deleteFile(PERSONAL_LOG_FILE);
        deleteFile(FAKE_EXE_FILE);
        deleteFile(INTERSLAVIC_PUZZLE_FILE);
        
        // Clean up config directory
        File configDir = new File(MOD_CONFIG_DIR);
        if (configDir.exists()) {
            deleteDirectory(configDir);
        }
    }

    /**
     * Deletes a file if it exists.
     */
    private void deleteFile(String fileName) {
        File file = new File(fileName);
        if (file.exists()) {
            file.delete();
            LogManager.getLogger("PuzzleFileManager").info("Deleted file: {}", fileName);
        }
    }
}
