package com.pulseoftheforsaken.simplelogger;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Zarządza efektem Horror HUD: glitch, szeptami, fałszywymi błędami i input lagiem.
 */
public class HorrorHUDManager {

    private static HorrorHUDManager instance;
    private boolean enabled = false;
    private int glitchTimer = 0;
    private int whisperTimer = 0;
    private int errorTimer = 0;
    private int inputLagTimer = 0;
    private final RandomSource random = RandomSource.create();
    
    private static boolean entityBehindPlayerActive = false;
    private static int entityBehindPlayerTimer = 0;
    
    // Nowe zmienne dla efektów psychologicznych
    private Vec3 lastPlayerPosition = null;
    private int standingStillTimer = 0;
    private static final int STANDING_STILL_THRESHOLD = 200; // 10 sekund (20 ticków/s)
    
    private static final ResourceLocation[] GLITCH_OVERLAYS = new ResourceLocation[] {
        new ResourceLocation("pulseoftheforsaken", "assets/glitch_01.png"),
        new ResourceLocation("pulseoftheforsaken", "assets/glitch_02.png"),
        new ResourceLocation("pulseoftheforsaken", "assets/glitch_03.png")
    };
    private static int glitchOverlayTimer = 0;
    private static int glitchOverlayIdx = 0;
    
    private static final ResourceLocation GLITCH_FLASH = new ResourceLocation("pulseoftheforsaken", "assets/glitch_flash.png");
    private static int glitchFlashTimer = 0;
    
    private static final Logger LOGGER = LoggerFactory.getLogger(HorrorHUDManager.class);
    
    private HorrorHUDManager() {}
    
    public static HorrorHUDManager getInstance() {
        if (instance == null) {
            instance = new HorrorHUDManager();
        }
        return instance;
    }
    
    public static void enable() {
        getInstance().enabled = true;
    }
    
    public static void disable() {
        getInstance().enabled = false;
    }
    
    public static boolean isEnabled() {
        return getInstance().enabled;
    }
    
    public static void update() {
        if (!isEnabled()) return;
        
        HorrorHUDManager manager = getInstance();
        // Aktualizacja timerów
        if (manager.glitchTimer > 0) manager.glitchTimer--;
        if (manager.whisperTimer > 0) manager.whisperTimer--;
        if (manager.errorTimer > 0) manager.errorTimer--;
        if (manager.inputLagTimer > 0) manager.inputLagTimer--;
        
        // Sprawdzanie bezruchu gracza
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player != null) {
            Vec3 currentPos = minecraft.player.position();
            if (manager.lastPlayerPosition != null && 
                currentPos.distanceToSqr(manager.lastPlayerPosition) < 0.01) {
                manager.standingStillTimer++;
                if (manager.standingStillTimer == STANDING_STILL_THRESHOLD) {
                    triggerStandingStillEffect();
                }
            } else {
                manager.standingStillTimer = 0;
            }
            manager.lastPlayerPosition = currentPos;
        }
        
        // Losowe efekty
        if (manager.random.nextInt(1000) == 0) {
            triggerGlitchEffect();
        }
        if (manager.random.nextInt(2000) == 0) {
            triggerWhisper();
        }
        if (manager.random.nextInt(3000) == 0) {
            triggerFakeError();
        }
        if (manager.random.nextInt(4000) == 0) {
            triggerInputLag();
        }
        if (manager.random.nextInt(5000) == 0) {
            triggerMirrorEffect();
        }
        if (manager.random.nextInt(6000) == 0) {
            triggerSkyEyesEffect();
        }
        if (manager.random.nextInt(7000) == 0) {
            triggerGUIEffect();
        }
        if (manager.random.nextInt(8000) == 0) {
            triggerInventoryEffect();
        }
        if (manager.random.nextInt(9000) == 0) {
            triggerMatrixEffect();
        }
        
        // Efekt "entity behind player"
        if (entityBehindPlayerActive && entityBehindPlayerTimer > 0) {
            entityBehindPlayerTimer--;
            if (entityBehindPlayerTimer == 0) {
                entityBehindPlayerActive = false;
            }
        }
        
        HeartbeatEffect.update();
        QREffect.update();
        
        // Glitch overlay przy niskim psyche
        if (PsycheManager.isLowPsyche()) {
            if (glitchOverlayTimer <= 0) {
                glitchOverlayIdx = getInstance().random.nextInt(GLITCH_OVERLAYS.length);
                glitchOverlayTimer = 20 + getInstance().random.nextInt(20); // 1-2 sekundy
            } else {
                glitchOverlayTimer--;
            }
        } else {
            glitchOverlayTimer = 0;
        }
        
        // Glitch flash przy bardzo niskiej psyche
        if (PsycheManager.getPsyche() < 15) {
            if (glitchFlashTimer <= 0) {
                glitchFlashTimer = 10; // 0.5 sekundy
                Minecraft mc = Minecraft.getInstance();
                if (mc.player != null) {
                    mc.player.playSound(
                        net.minecraft.sounds.SoundEvent.createVariableRangeEvent(
                            new net.minecraft.resources.ResourceLocation("pulseoftheforsaken", "disconnect_fail")
                        ),
                        1.0F, 1.0F
                    );
                }
            } else {
                glitchFlashTimer--;
            }
        } else {
            glitchFlashTimer = 0;
        }
        
        MirrorEffect.update();
    }
    
    public static void render(GuiGraphics guiGraphics) {
        if (!isEnabled()) return;
        
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null) return;
        
        HorrorHUDManager manager = getInstance();
        // Efekt glitcha
        if (manager.glitchTimer > 0) {
            renderGlitchEffect(guiGraphics);
        }
        
        // Efekt szeptu
        if (manager.whisperTimer > 0) {
            renderWhisper(guiGraphics);
        }
        
        // Fałszywy błąd
        if (manager.errorTimer > 0) {
            renderFakeError(guiGraphics);
        }
        
        // Renderuj "entity behind player"
        if (entityBehindPlayerActive) {
            if (minecraft.player != null) {
                int width = guiGraphics.guiWidth();
                int height = guiGraphics.guiHeight();
                // Wyświetl teksturę entity2137_skin.png na środku ekranu, lekko za gracza
                guiGraphics.blit(ResourceManager.ENTITY_2137_SKIN, width / 2 - 32, height / 2 + 40, 0, 0, 64, 64, 64, 64);
            }
        }
        
        // Glitch overlay
        if (PsycheManager.isLowPsyche() && glitchOverlayTimer > 0) {
            ResourceLocation overlay = GLITCH_OVERLAYS[glitchOverlayIdx];
            int width = guiGraphics.guiWidth();
            int height = guiGraphics.guiHeight();
            guiGraphics.blit(overlay, 0, 0, 0, 0, width, height, width, height);
        }
        
        // Glitch flash overlay
        if (glitchFlashTimer > 0) {
            int width = guiGraphics.guiWidth();
            int height = guiGraphics.guiHeight();
            guiGraphics.blit(GLITCH_FLASH, 0, 0, 0, 0, width, height, width, height);
        }
    }
    
    public static void triggerGlitchEffect() {
        HorrorHUDManager manager = getInstance();
        manager.glitchTimer = 20;
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player != null) {
            // Losowa wariacja glitcha
            float volume = 0.4F + (manager.random.nextFloat() * 0.3F); // 0.4-0.7
            float pitch = 0.4F + (manager.random.nextFloat() * 0.3F); // 0.4-0.7
            minecraft.player.playSound(SoundEvents.AMBIENT_CAVE.get(), volume, pitch);
        }
    }
    
    public static void triggerWhisper() {
        HorrorHUDManager manager = getInstance();
        manager.whisperTimer = 60;
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player != null) {
            // Losowa wariacja szeptu
            float volume = 0.6F + (manager.random.nextFloat() * 0.4F); // 0.6-1.0
            float pitch = 0.8F + (manager.random.nextFloat() * 0.8F); // 0.8-1.6
            minecraft.player.playSound(
                net.minecraft.sounds.SoundEvent.createVariableRangeEvent(
                    new net.minecraft.resources.ResourceLocation("pulseoftheforsaken", "whispers_distorted")
                ),
                volume, pitch
            );
        }
    }
    
    public static void triggerFakeError() {
        HorrorHUDManager manager = getInstance();
        manager.errorTimer = 100;
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player != null) {
            // Losowa wariacja błędu
            float volume = 0.8F + (manager.random.nextFloat() * 0.4F); // 0.8-1.2
            float pitch = 0.4F + (manager.random.nextFloat() * 0.3F); // 0.4-0.7
            minecraft.player.playSound(
                net.minecraft.sounds.SoundEvent.createVariableRangeEvent(
                    new net.minecraft.resources.ResourceLocation("pulseoftheforsaken", "pulse_error")
                ),
                volume, pitch
            );
        }
    }
    
    public static void triggerInputLag() {
        HorrorHUDManager manager = getInstance();
        manager.inputLagTimer = 40;
    }
    
    public static void triggerJumpscare() {
        if (!isEnabled()) return;
        
        // Odtwórz dźwięk jumpscare'a
        ResourceManager.getInstance().playJumpscareSound();
        
        // Pokaż teksturę jumpscare'a
        // TODO: Implementacja wyświetlania tekstury jumpscare'a
    }
    
    public static void triggerEntityBehindPlayer() {
        entityBehindPlayerActive = true;
        entityBehindPlayerTimer = 200;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            // Losowa wariacja oddechu
            float volume = 0.7F + (getInstance().random.nextFloat() * 0.6F); // 0.7-1.3
            float pitch = 0.5F + (getInstance().random.nextFloat() * 0.4F); // 0.5-0.9
            mc.player.playSound(
                net.minecraft.sounds.SoundEvent.createVariableRangeEvent(
                    new net.minecraft.resources.ResourceLocation("pulseoftheforsaken", "entity_breath")
                ),
                volume, pitch
            );
        }
    }
    
    private static void renderGlitchEffect(GuiGraphics guiGraphics) {
        HorrorHUDManager manager = getInstance();
        int width = guiGraphics.guiWidth();
        int height = guiGraphics.guiHeight();
        
        // Losowe przesunięcie ekranu
        int offsetX = manager.random.nextIntBetweenInclusive(-5, 5);
        int offsetY = manager.random.nextIntBetweenInclusive(-5, 5);
        
        // Losowe linie
        for (int i = 0; i < 10; i++) {
            int x = manager.random.nextInt(width);
            int y = manager.random.nextInt(height);
            int length = manager.random.nextIntBetweenInclusive(50, 200);
            guiGraphics.fill(x, y, x + length, y + 1, 0xFFFF0000);
        }
    }
    
    private static void renderWhisper(GuiGraphics guiGraphics) {
        HorrorHUDManager manager = getInstance();
        Minecraft minecraft = Minecraft.getInstance();
        String playerName = minecraft.player != null ? minecraft.player.getName().getString() : "Player";
        String osName = System.getProperty("os.name");
        
        String[] whispers = {
            "I see you, " + playerName + "...",
            "You can't escape, " + playerName + "...",
            "You are alone, " + playerName + "...",
            "Do you hear that, " + playerName + "?",
            "Behind you, " + playerName + "...",
            "Your system, " + osName + ", is vulnerable...",
            "I'm watching you through " + osName + "..."
        };
        String whisper = whispers[manager.random.nextInt(whispers.length)];
        int width = guiGraphics.guiWidth();
        int height = guiGraphics.guiHeight();
        guiGraphics.drawString(Minecraft.getInstance().font, whisper, 
            width / 2 - Minecraft.getInstance().font.width(whisper) / 2,
            height / 2, 0xFFFF0000);
    }
    
    private static void renderFakeError(GuiGraphics guiGraphics) {
        HorrorHUDManager manager = getInstance();
        String[] errors = {
            "ERROR: Unable to load textures",
            "ERROR: Lost connection to server",
            "ERROR: Invalid server response",
            "ERROR: Resource access denied",
            "ERROR: Unexpected exception"
        };
        String error = errors[manager.random.nextInt(errors.length)];
        int width = guiGraphics.guiWidth();
        guiGraphics.fill(0, 0, width, 20, 0x80000000);
        guiGraphics.drawString(Minecraft.getInstance().font, error, 5, 5, 0xFFFF0000);
    }
    
    private static void triggerStandingStillEffect() {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player != null) {
            minecraft.player.playSound(SoundEvents.AMBIENT_CAVE.get(), 0.5F, 0.8F);
            minecraft.gui.getChat().addRecentChat("§c§oDo you hear that too?");
        }
    }
    
    public static void triggerMirrorEffect() {
        LOGGER.info("Triggering mirror effect");
        MirrorEffect.activate();
        if (Minecraft.getInstance().player != null) {
            float volume = 0.3F + (float)(Math.random() * 0.2);
            float pitch = 0.8F + (float)(Math.random() * 0.4);
            LOGGER.debug("Playing mirror effect sound with volume: {} and pitch: {}", volume, pitch);
            Minecraft.getInstance().player.playSound(
                SoundEvents.AMBIENT_CAVE.get(),
                volume,
                pitch
            );
        }
    }
    
    public static void triggerSkyEyesEffect() {
        if (Minecraft.getInstance().player != null) {
            float volume = 0.2F + (float)(Math.random() * 0.1);
            float pitch = 0.6F + (float)(Math.random() * 0.3);
            Minecraft.getInstance().player.playSound(
                SoundEvents.AMBIENT_CAVE.get(),
                volume,
                pitch
            );
        }
    }
    
    public static void triggerGUIEffect() {
        if (Minecraft.getInstance().player != null) {
            float volume = 0.4F + (float)(Math.random() * 0.2);
            float pitch = 1.0F + (float)(Math.random() * 0.5);
            Minecraft.getInstance().player.playSound(
                SoundEvents.UI_BUTTON_CLICK.get(),
                volume,
                pitch
            );
        }
    }
    
    public static void triggerInventoryEffect() {
        if (Minecraft.getInstance().player != null) {
            float volume = 0.3F + (float)(Math.random() * 0.2);
            float pitch = 0.8F + (float)(Math.random() * 0.4);
            Minecraft.getInstance().player.playSound(
                SoundEvents.ITEM_PICKUP,
                volume,
                pitch
            );
        }
    }
    
    public static void triggerMatrixEffect() {
        if (Minecraft.getInstance().player != null) {
            float volume = 0.5F + (float)(Math.random() * 0.3);
            float pitch = 1.2F + (float)(Math.random() * 0.6);
            Minecraft.getInstance().player.playSound(
                SoundEvents.AMBIENT_CAVE.get(),
                volume,
                pitch
            );
        }
    }
    
    public static void triggerHeartbeatEffect() {
        HeartbeatEffect.activate();
    }
    
    public static void triggerQREffect() {
        QREffect.activate();
    }

    public static void triggerScanPing() {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player != null) {
            minecraft.player.playSound(
                SoundEvent.createVariableRangeEvent(
                    new ResourceLocation("pulseoftheforsaken", "scan_ping")
                ),
                0.5F, 1.5F
            );
        }
    }

    public static void triggerPsycheDrop() {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player != null) {
            minecraft.player.playSound(
                SoundEvent.createVariableRangeEvent(
                    new ResourceLocation("pulseoftheforsaken", "psyche_drop")
                ),
                1.0F, 0.3F
            );
        }
    }
}
