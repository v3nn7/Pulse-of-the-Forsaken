package com.pulseoftheforsaken.simplelogger;

import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.sounds.SoundManager;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import com.pulseoftheforsaken.config.ModConfig;
import com.pulseoftheforsaken.client.gui.ArchamConsentScreen;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod.EventBusSubscriber
public class ArchamLanguageManager {
    private static final Logger LOGGER = LogManager.getLogger();
    private static boolean isInitialized = false;
    private static final ResourceLocation ARCHAM_SOUND = new ResourceLocation("pulseoftheforsaken", "archam_ambient");
    private static final SoundEvent ARCHAM_AMBIENT = SoundEvent.createVariableRangeEvent(ARCHAM_SOUND);

    public static void initialize() {
        if (!isInitialized) {
            try {
                isInitialized = true;
                LOGGER.info("ArchamLanguageManager initialized successfully");
            } catch (Exception e) {
                LOGGER.error("Failed to initialize ArchamLanguageManager: {}", e.getMessage());
                e.printStackTrace();
            }
        }
    }

    public static void unlockArchamLanguage() {
        try {
            LOGGER.info("Attempting to unlock Archam language");
            ModConfig.setArchamLanguageEnabled(true);
            ModConfig.ARCHAM_LANGUAGE_ENABLED.save();
            LOGGER.info("Archam language unlocked successfully");
        } catch (Exception e) {
            LOGGER.error("Failed to unlock Archam language: {}", e.getMessage());
            e.printStackTrace();
        }
    }

    @SubscribeEvent
    public static void onScreenOpen(ScreenEvent.Opening event) {
        try {
            if (!ModConfig.isArchamLanguageEnabled()) {
                Screen screen = event.getNewScreen();
                if (screen != null && !(screen instanceof ArchamConsentScreen)) {
                    event.setCanceled(true);
                    Minecraft minecraft = Minecraft.getInstance();
                    if (minecraft != null) {
                        minecraft.setScreen(new ArchamConsentScreen());
                        
                        // Odtwarzanie dźwięku
                        try {
                            SoundManager soundManager = minecraft.getSoundManager();
                            if (soundManager != null) {
                                soundManager.play(
                                    net.minecraft.client.resources.sounds.SimpleSoundInstance.forUI(
                                        ARCHAM_AMBIENT, 1.0F, 0.5F
                                    )
                                );
                                LOGGER.info("Archam ambient sound played successfully");
                            }
                        } catch (Exception e) {
                            LOGGER.error("Failed to play sound: {}", e.getMessage());
                        }
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.error("Error in onScreenOpen: {}", e.getMessage());
            e.printStackTrace();
        }
    }
} 