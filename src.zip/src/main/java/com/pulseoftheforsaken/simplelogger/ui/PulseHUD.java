package com.pulseoftheforsaken.simplelogger.ui;

import com.pulseoftheforsaken.simplelogger.HorrorHUDManager;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.ItemStack;

public class PulseHUD extends Screen implements MenuProvider {
    private final HorrorHUDManager horrorManager;
    private Button toggleButton;
    private Button closeButton;

    public PulseHUD() {
        super(Component.literal("Pulse of the Forsaken"));
        this.horrorManager = HorrorHUDManager.getInstance();
    }

    @Override
    protected void init() {
        super.init();
        
        // Toggle button
        this.toggleButton = Button.builder(
            Component.literal(horrorManager.isEnabled() ? "Wyłącz efekty horroru" : "Włącz efekty horroru"),
            button -> {
                if (horrorManager.isEnabled()) {
                    horrorManager.disable();
                } else {
                    horrorManager.enable();
                }
                button.setMessage(Component.literal(horrorManager.isEnabled() ? "Wyłącz efekty horroru" : "Włącz efekty horroru"));
            })
            .pos(width / 2 - 100, height / 2 - 24)
            .size(200, 20)
            .build();
        
        // Close button
        this.closeButton = Button.builder(
            Component.literal("Zamknij"),
            button -> onClose())
            .pos(width / 2 - 100, height / 2 + 4)
            .size(200, 20)
            .build();
            
        addRenderableWidget(toggleButton);
        addRenderableWidget(closeButton);
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
        renderBackground(guiGraphics);
        super.render(guiGraphics, mouseX, mouseY, partialTicks);
        
        // Title
        guiGraphics.drawCenteredString(font, "Pulse of the Forsaken", width / 2, 20, 0xFFFFFF);
        
        // Status
        String status = horrorManager.isEnabled() ? "Aktywny" : "Nieaktywny";
        guiGraphics.drawCenteredString(font, "Status: " + status, width / 2, height / 2 - 50, 0xFFFFFF);
    }

    @Override
    public boolean isPauseScreen() {
        return true;
    }

    @Override
    public Component getDisplayName() {
        return Component.literal("Pulse of the Forsaken");
    }

    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory inventory, Player player) {
        return new PulseContainer(containerId, inventory, player);
    }
}

class PulseContainer extends AbstractContainerMenu {
    public PulseContainer(int containerId, Inventory inventory, Player player) {
        super(MenuType.GENERIC_9x3, containerId);
    }

    @Override
    public boolean stillValid(Player player) {
        return true;
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        return ItemStack.EMPTY; // Nie pozwalamy na przenoszenie przedmiotów
    }
} 