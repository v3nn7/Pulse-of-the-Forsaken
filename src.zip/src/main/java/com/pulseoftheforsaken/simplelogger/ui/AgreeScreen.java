package com.pulseoftheforsaken.simplelogger.ui;

import com.pulseoftheforsaken.simplelogger.util.SimpleLogger;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.network.chat.Style;
import net.minecraft.ChatFormatting;
import java.lang.Runnable;

public class AgreeScreen extends Screen {
    private final Runnable onAccept;
    private static final int BUTTON_WIDTH = 200;
    private static final int BUTTON_HEIGHT = 20;
    private static final int BUTTON_SPACING = 10;
    private boolean hasAgreed = false;
    private int tickCount = 0;
    private final ResourceLocation BACKGROUND_TEXTURE = new ResourceLocation("pulseoftheforsaken", "assets/gui/agreement_background.png");
    private final RandomSource random = RandomSource.create();
    private int glitchTimer = 0;
    private boolean showGlitch = false;
    private int redFlashTimer = 0;
    private static final String DISCORD_LINK = "https://discord.gg/GmsFRGfpaQ";
    private static final String GUILDED_LINK = "https://www.guilded.gg/i/E0qjQbj2";
    
    // Text effects
    private final String[] warningTexts = {
        "WARNING: This mod contains disturbing content.",
        "The mod creates an immersive horror experience.",
        "Some effects may be startling or unsettling.",
        "Play at your own risk.",
        "Are you sure you want to continue?"
    };

    public AgreeScreen(Runnable onAccept) {
        super(Component.literal("Pulse of the Forsaken - Consent"));
        this.onAccept = onAccept;
        
        // Play ambient sound when screen opens
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level != null && minecraft.player != null) {
            minecraft.level.playSound(
                minecraft.player,
                minecraft.player.getX(),
                minecraft.player.getY(),
                minecraft.player.getZ(),
                SoundEvents.AMBIENT_CAVE.get(),
                SoundSource.AMBIENT,
                0.5F,
                0.8F
            );
        }
        
        // Schedule random glitch effects
        this.glitchTimer = 20 + random.nextInt(40);
    }

    @Override
    protected void init() {
        super.init();
        
        int centerX = this.width / 2;
        int centerY = this.height / 2;
        
        // Accept button with horror styling
        Button acceptButton = Button.builder(
            Component.literal("I Accept").withStyle(Style.EMPTY.withColor(ChatFormatting.RED).withBold(true)), 
            (button) -> {
                if (!hasAgreed) {
                    hasAgreed = true;
                    // Play creepy sound on acceptance
                    Minecraft minecraft = Minecraft.getInstance();
                    if (minecraft.level != null && minecraft.player != null) {
                        // Play multiple sounds for a more dramatic effect
                        minecraft.level.playSound(
                            minecraft.player, 
                            minecraft.player.getX(), 
                            minecraft.player.getY(), 
                            minecraft.player.getZ(), 
                            SoundEvents.AMBIENT_CAVE.get(), 
                            SoundSource.MASTER, 
                            1.0F, 
                            0.5F
                        );
                        
                        // Add a slight delay before playing the second sound
                        minecraft.tell(() -> {
                            if (minecraft.level != null && minecraft.player != null) {
                                minecraft.level.playSound(
                                    minecraft.player,
                                    minecraft.player.getX(),
                                    minecraft.player.getY(),
                                    minecraft.player.getZ(),
                                    SoundEvents.AMBIENT_SOUL_SAND_VALLEY_MOOD.get(),
                                    SoundSource.MASTER,
                                    0.8F,
                                    0.7F
                                );
                            }
                        });
                    }
                    
                    // Trigger a final glitch effect before closing
                    triggerGlitchEffect();
                    
                    // Run the acceptance callback and close the screen
                    onAccept.run();
                    Minecraft.getInstance().setScreen(null);
                }
            }
        )
        .pos(centerX - BUTTON_WIDTH / 2, centerY + BUTTON_SPACING)
        .size(BUTTON_WIDTH, BUTTON_HEIGHT)
        .tooltip(Tooltip.create(Component.literal("Click to accept and continue").withStyle(ChatFormatting.RED)))
        .build();
        
        // Discord button
        Button discordButton = Button.builder(
            Component.literal("Discord").withStyle(Style.EMPTY.withColor(ChatFormatting.BLUE).withBold(true)), 
            (button) -> {
                openLink(DISCORD_LINK);
            }
        )
        .pos(centerX - BUTTON_WIDTH - BUTTON_SPACING, centerY + BUTTON_HEIGHT + BUTTON_SPACING * 2)
        .size(BUTTON_WIDTH, BUTTON_HEIGHT)
        .tooltip(Tooltip.create(Component.literal("Join our Discord community!").withStyle(ChatFormatting.BLUE)))
        .build();

        // Guilded button
        Button guildedButton = Button.builder(
            Component.literal("Guilded").withStyle(Style.EMPTY.withColor(ChatFormatting.DARK_PURPLE).withBold(true)), 
            (button) -> {
                openLink(GUILDED_LINK);
            }
        )
        .pos(centerX + BUTTON_SPACING, centerY + BUTTON_HEIGHT + BUTTON_SPACING * 2)
        .size(BUTTON_WIDTH, BUTTON_HEIGHT)
        .tooltip(Tooltip.create(Component.literal("Join our Guilded community!").withStyle(ChatFormatting.DARK_PURPLE)))
        .build();

        this.addRenderableWidget(acceptButton);
        this.addRenderableWidget(discordButton);
        this.addRenderableWidget(guildedButton);
    }

    @Override
    public void tick() {
        super.tick();
        tickCount++;
        
        // Random glitch effects
        if (random.nextInt(200) < 5) {
            glitchTimer = 5 + random.nextInt(10);
            showGlitch = true;
            
            // Occasionally play a subtle sound with the glitch
            if (random.nextInt(3) == 0) {
                Minecraft minecraft = Minecraft.getInstance();
                if (minecraft.level != null && minecraft.player != null) {
                    // Choose a random ambient sound
                    net.minecraft.sounds.SoundEvent soundEvent;
                    int soundChoice = random.nextInt(4);
                    float pitch = 0.5F + (random.nextFloat() * 0.5F);
                    float volume = 0.2F + (random.nextFloat() * 0.3F);
                    
                    switch (soundChoice) {
                        case 0:
                            soundEvent = SoundEvents.AMBIENT_CAVE.get();
                            break;
                        case 1:
                            soundEvent = SoundEvents.AMBIENT_BASALT_DELTAS_MOOD.get();
                            break;
                        case 2:
                            soundEvent = SoundEvents.AMBIENT_SOUL_SAND_VALLEY_MOOD.get();
                            break;
                        default:
                            soundEvent = SoundEvents.AMBIENT_NETHER_WASTES_MOOD.get();
                            break;
                    }
                    
                    minecraft.level.playSound(
                        minecraft.player,
                        minecraft.player.getX(),
                        minecraft.player.getY(),
                        minecraft.player.getZ(),
                        soundEvent,
                        SoundSource.AMBIENT,
                        volume,
                        pitch
                    );
                }
            }
        }
        
        if (glitchTimer > 0) {
            glitchTimer--;
        } else {
            showGlitch = false;
        }
        
        if (redFlashTimer > 0) {
            redFlashTimer--;
        }
        
        // Trigger a major glitch effect occasionally
        if (tickCount > 100 && random.nextInt(100) == 0) {
            triggerGlitchEffect();
        }
    }
    
    private void triggerGlitchEffect() {
        glitchTimer = 20;
        showGlitch = true;
        redFlashTimer = 10;
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level != null && minecraft.player != null) {
            minecraft.level.playSound(
                minecraft.player, 
                minecraft.player.getX(), 
                minecraft.player.getY(), 
                minecraft.player.getZ(), 
                SoundEvents.AMBIENT_CAVE.get(), 
                SoundSource.MASTER, 
                1.0F, 
                0.2F
            );
        }
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        // Render dark background
        this.renderBackground(guiGraphics);
        
        // Try to render background texture if it exists
        try {
            int textureWidth = 256;
            int textureHeight = 256;
            guiGraphics.blit(BACKGROUND_TEXTURE, 
                this.width / 2 - textureWidth / 2, 
                this.height / 2 - textureHeight / 2, 
                0, 0, textureWidth, textureHeight, 
                textureWidth, textureHeight);
        } catch (Exception e) {
            // If texture doesn't exist, just use a dark overlay
            SimpleLogger.warn("Could not render background texture: " + e.getMessage());
        }
        
        // Add a semi-transparent dark overlay for better text readability
        int overlayAlpha = showGlitch ? 
            0x99 + random.nextIntBetweenInclusive(-10, 10) : 
            0x99;
        guiGraphics.fill(0, 0, this.width, this.height, (overlayAlpha << 24) | 0x000000);
        
        // Add occasional static noise when glitching
        if (showGlitch && random.nextInt(3) == 0) {
            for (int i = 0; i < 20; i++) {
                int x = random.nextInt(this.width);
                int y = random.nextInt(this.height);
                int width = random.nextIntBetweenInclusive(1, 5);
                int height = random.nextIntBetweenInclusive(1, 5);
                int color = random.nextBoolean() ? 0x55FFFFFF : 0x55FF0000;
                guiGraphics.fill(x, y, x + width, y + height, color);
            }
        }
        
        // Title with horror style and glitch effect
        int titleXOffset = showGlitch ? random.nextIntBetweenInclusive(-3, 3) : 0;
        Component titleText = Component.literal("Pulse of the Forsaken - Consent")
            .withStyle(Style.EMPTY.withColor(showGlitch ? ChatFormatting.RED : ChatFormatting.DARK_RED).withBold(true));
        guiGraphics.drawCenteredString(this.font, titleText, this.width / 2 + titleXOffset, 20, 0xFFFFFF);
        
        // Consent text
        String[] consentText = {
            "Pulse of the Forsaken is a horror mod that:",
            "- Creates log files in your game directory",
            "- May display disturbing content and images",
            "- Contains jumpscares and horror elements",
            "- Uses audio effects for immersion",
            "",
            "This mod is intended for mature audiences.",
            "Do you accept these terms?",
            "",
            "Join our community:",
            "Discord: " + DISCORD_LINK,
            "Guilded: " + GUILDED_LINK
        };
        
        int y = 60;
        for (String line : consentText) {
            // Add slight glitch effect to text
            int xOffset = (showGlitch && random.nextInt(10) == 0) ? random.nextIntBetweenInclusive(-2, 2) : 0;
            
            // Format text based on content
            Component textComponent;
            if (line.startsWith("-")) {
                textComponent = Component.literal(line).withStyle(ChatFormatting.GRAY);
            } else if (line.contains("Discord:")) {
                textComponent = Component.literal(line).withStyle(ChatFormatting.BLUE);
            } else if (line.contains("Guilded:")) {
                textComponent = Component.literal(line).withStyle(ChatFormatting.DARK_PURPLE);
            } else if (line.equals("This mod is intended for mature audiences.")) {
                textComponent = Component.literal(line).withStyle(Style.EMPTY.withColor(ChatFormatting.RED).withBold(true));
            } else if (line.equals("Do you accept these terms?")) {
                textComponent = Component.literal(line).withStyle(Style.EMPTY.withColor(ChatFormatting.GOLD).withBold(true));
            } else if (line.startsWith("Pulse of the Forsaken")) {
                textComponent = Component.literal(line).withStyle(Style.EMPTY.withColor(ChatFormatting.DARK_RED).withBold(true));
            } else {
                textComponent = Component.literal(line).withStyle(ChatFormatting.WHITE);
            }
            
            guiGraphics.drawCenteredString(this.font, textComponent, this.width / 2 + xOffset, y, 0xFFFFFF);
            y += 12;
        }
        
        // Red flash effect
        if (redFlashTimer > 0) {
            guiGraphics.fill(0, 0, this.width, this.height, 0x55FF0000);
        }
        
        // Warnings with horror styling
        for (int i = 0; i < warningTexts.length; i++) {
            int yPos = this.height / 2 - 10 + i * 15;
            int xOffset = showGlitch ? random.nextIntBetweenInclusive(-3, 3) : 0;
            int yOffset = showGlitch ? random.nextIntBetweenInclusive(-1, 1) : 0;
            
            // Make the last warning (Are you sure?) more prominent
            if (i == warningTexts.length - 1) {
                // Pulsating effect for the last warning
                float pulseIntensity = (float) Math.sin(tickCount * 0.1) * 0.5f + 0.5f;
                int red = (int) (255 * pulseIntensity);
                ChatFormatting color = showGlitch ? ChatFormatting.DARK_RED : ChatFormatting.RED;
                
                Component warningText = Component.literal(warningTexts[i])
                    .withStyle(Style.EMPTY.withColor(color).withBold(true));
                guiGraphics.drawCenteredString(this.font, warningText, this.width / 2 + xOffset, yPos + yOffset, 0xFFFFFF);
            } else {
                // Random flickering for other warnings
                boolean flicker = showGlitch && random.nextInt(10) == 0;
                ChatFormatting color = flicker ? ChatFormatting.DARK_RED : 
                                     (showGlitch ? ChatFormatting.RED : ChatFormatting.GRAY);
                
                Component warningText = Component.literal(warningTexts[i])
                    .withStyle(Style.EMPTY.withColor(color));
                guiGraphics.drawCenteredString(this.font, warningText, this.width / 2 + xOffset, yPos + yOffset, 0xFFFFFF);
            }
        }
        
        super.render(guiGraphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    public boolean isPauseScreen() {
        return false; // Screen doesn't pause the game
    }

    private void openLink(String url) {
        try {
            // Use Minecraft's built-in method to open URLs safely
            net.minecraft.Util.getPlatform().openUri(url);
        } catch (Exception e) {
            SimpleLogger.error("Could not open link: " + e.getMessage());
        }
    }
}
