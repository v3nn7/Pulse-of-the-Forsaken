package com.pulseoftheforsaken.simplelogger;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import net.minecraft.util.RandomSource;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.HashMap;
import java.util.Map;

/**
 * Klasa obsługująca efekty GUI
 */
public class GUIEffect {
    private static final RandomSource random = RandomSource.create();
    private static boolean isGUIActive = false;
    private static int guiDuration = 0;
    private static final int GUI_DURATION = 40; // 2 sekundy (20 ticków/s)
    
    // Mapowanie oryginalnych tekstów na zmienione
    private static final Map<String, String> textMappings = new HashMap<>();
    static {
        textMappings.put("Play", "Stay");
        textMappings.put("Quit", "Don't");
        textMappings.put("Options", "Settings");
        textMappings.put("Singleplayer", "Alone");
        textMappings.put("Multiplayer", "Together");
        textMappings.put("Back", "Forward");
        textMappings.put("Done", "Continue");
        textMappings.put("Cancel", "Proceed");
        textMappings.put("Yes", "No");
        textMappings.put("No", "Yes");
    }
    
    /**
     * Aktywuje efekt GUI
     */
    public static void activateGUIEffect() {
        isGUIActive = true;
        guiDuration = GUI_DURATION;
    }
    
    /**
     * Aktualizuje stan efektu GUI
     */
    public static void update() {
        if (!isGUIActive) return;
        
        guiDuration--;
        
        // Zakończ efekt
        if (guiDuration <= 0) {
            isGUIActive = false;
        }
    }
    
    /**
     * Obsługuje zdarzenie renderowania GUI
     */
    @SubscribeEvent
    public static void onRenderOverlay(RenderGuiOverlayEvent.Post event) {
        if (!isGUIActive) return;
        
        // Losowo zmień teksty przycisków
        if (random.nextInt(20) == 0) {
            Minecraft minecraft = Minecraft.getInstance();
            if (minecraft.screen != null) {
                minecraft.screen.children().stream()
                    .filter(widget -> widget instanceof Button)
                    .map(widget -> (Button) widget)
                    .forEach(button -> {
                        String originalText = button.getMessage().getString();
                        String newText = textMappings.getOrDefault(originalText, originalText);
                        if (!newText.equals(originalText)) {
                            button.setMessage(Component.literal(newText));
                        }
                    });
            }
        }
    }
    
    /**
     * Obsługuje zdarzenie inicjalizacji ekranu
     */
    @SubscribeEvent
    public static void onScreenInit(ScreenEvent.Init event) {
        if (!isGUIActive) return;
        
        // Zmień teksty przycisków przy inicjalizacji ekranu
        event.getScreen().children().stream()
            .filter(widget -> widget instanceof Button)
            .map(widget -> (Button) widget)
            .forEach(button -> {
                String originalText = button.getMessage().getString();
                String newText = textMappings.getOrDefault(originalText, originalText);
                if (!newText.equals(originalText)) {
                    button.setMessage(Component.literal(newText));
                }
            });
    }
    
    /**
     * Sprawdza, czy efekt GUI jest aktywny
     */
    public static boolean isGUIActive() {
        return isGUIActive;
    }
} 