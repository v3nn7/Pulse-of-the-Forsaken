package com.pulseoftheforsaken.simplelogger;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.RandomSource;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * Klasa obsługująca efekt pustego inventory
 */
public class InventoryEffect {
    private static final RandomSource random = RandomSource.create();
    private static boolean isInventoryEffectActive = false;
    private static int inventoryEffectDuration = 0;
    private static final int INVENTORY_EFFECT_DURATION = 20; // 1 sekunda (20 ticków/s)
    
    /**
     * Aktywuje efekt pustego inventory
     */
    public static void activateInventoryEffect() {
        isInventoryEffectActive = true;
        inventoryEffectDuration = INVENTORY_EFFECT_DURATION;
        
        // Wyświetl wiadomość
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player != null) {
            minecraft.player.displayClientMessage(Component.literal("§c§oYour inventory feels empty..."), true);
        }
    }
    
    /**
     * Aktualizuje stan efektu inventory
     */
    public static void update() {
        if (!isInventoryEffectActive) return;
        
        inventoryEffectDuration--;
        
        // Zakończ efekt
        if (inventoryEffectDuration <= 0) {
            isInventoryEffectActive = false;
        }
    }
    
    /**
     * Obsługuje zdarzenie renderowania ekranu inventory
     */
    @SubscribeEvent
    public static void onScreenRender(ScreenEvent.Render event) {
        if (!isInventoryEffectActive || !(event.getScreen() instanceof InventoryScreen)) return;
        
        GuiGraphics guiGraphics = event.getGuiGraphics();
        int width = guiGraphics.guiWidth();
        int height = guiGraphics.guiHeight();
        
        // Przykryj inventory czarnym prostokątem
        guiGraphics.fill(0, 0, width, height, 0xFF000000);
        
        // Wyświetl komunikat
        String message = "Your items are gone...";
        int messageWidth = Minecraft.getInstance().font.width(message);
        guiGraphics.drawString(Minecraft.getInstance().font, message,
            width / 2 - messageWidth / 2,
            height / 2,
            0xFFFF0000);
    }
    
    /**
     * Sprawdza, czy efekt inventory jest aktywny
     */
    public static boolean isInventoryEffectActive() {
        return isInventoryEffectActive;
    }
} 