package com.pulseoftheforsaken.simplelogger;

import com.pulseoftheforsaken.simplelogger.commands.PulseCommand;
import com.pulseoftheforsaken.simplelogger.config.PulseConfig;
import com.pulseoftheforsaken.simplelogger.ui.AgreeScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import net.minecraft.resources.ResourceLocation;

@Mod(SimpleLogger.MOD_ID)
public class SimpleLogger {
    public static final String MOD_ID = "pulseoftheforsaken";
    private static boolean hasAgreed = false;
    private static final Logger LOGGER = LoggerFactory.getLogger("PulseOfTheForsaken");
    
    public SimpleLogger() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        
        // Rejestracja dźwięków
        ResourceManager.SOUNDS.register(modEventBus);
        
        // Rejestracja konfiguracji
        PulseConfig.register();
        
        // Rejestracja eventów
        modEventBus.addListener(this::setup);
        modEventBus.addListener(this::clientSetup);
        
        MinecraftForge.EVENT_BUS.register(this);
    }
    
    private void setup(final FMLCommonSetupEvent event) {
        // Inicjalizacja moda po stronie serwera
    }
    
    @OnlyIn(Dist.CLIENT)
    private void clientSetup(final FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            hasAgreed = false;
            Minecraft.getInstance().setScreen(new AgreeScreen(() -> {
                hasAgreed = true;
                if (PulseConfig.areHorrorEffectsEnabled()) {
                    HorrorHUDManager.enable();
                }
            }));
        });
    }
    
    @SubscribeEvent
    public void onServerStarting(ServerStartingEvent event) {
        LOGGER.info("Registering commands for Pulse of the Forsaken");
        
        event.getServer().getCommands().getDispatcher().register(Commands.literal("pulse")
            .requires(source -> source.hasPermission(0))
            .executes(context -> {
                context.getSource().sendSuccess(() -> Component.literal("Use /pulse help for commands"), false);
                return 1;
            })
            .then(Commands.literal("help")
                .executes(context -> {
                    showHelp(context.getSource());
                    return 1;
                })
            )
        );
        
        // Rejestracja paranoicznej komendy /trust
        event.getServer().getCommands().getDispatcher().register(Commands.literal("trust")
            .requires(source -> source.hasPermission(0))
            .executes(context -> {
                // Nic się nie dzieje, ale gracz może próbować użyć tej komendy
                return 1;
            })
        );
    }
    
    private void showHelp(CommandSourceStack source) {
        source.sendSuccess(() -> Component.literal("§6=== Pulse of the Forsaken Commands ==="), false);
        source.sendSuccess(() -> Component.literal("§7/pulse help - Show this help"), false);
        source.sendSuccess(() -> Component.literal("§7/pulse status - Show mod status"), false);
        source.sendSuccess(() -> Component.literal("§7/pulse toggle - Toggle horror effects"), false);
        source.sendSuccess(() -> Component.literal("§7/pulse reset - Reset mod state"), false);
        source.sendSuccess(() -> Component.literal("§7/trust - Trust me..."), false);
    }
    
    @SubscribeEvent
    public void onPlayerDeath(LivingDeathEvent event) {
        if (event.getEntity() instanceof ServerPlayer) {
            ServerPlayer player = (ServerPlayer) event.getEntity();
            if (PulseConfig.areHorrorEffectsEnabled()) {
                // Aktywuj efekt ducha
                PlayerGhostEffect.activateGhostEffect();
                // Wyświetl wiadomość
                player.sendSystemMessage(Component.literal("§c§oYour soul lingers..."));
            }
        }
    }
    
    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.END) {
            // Aktualizacja efektów horroru
            if (PulseConfig.areHorrorEffectsEnabled()) {
                HorrorHUDManager.getInstance().update();
                PlayerGhostEffect.update();
                MirrorWorldEffect.update();
            }
        }
    }

    public static void info(String message) {
        LOGGER.info(message);
    }

    public static void warn(String message) {
        LOGGER.warn(message);
    }

    public static void error(String message) {
        LOGGER.error(message);
    }

    public static void debug(String message) {
        LOGGER.debug(message);
    }
} 