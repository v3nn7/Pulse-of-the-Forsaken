package com.pulseoftheforsaken.simplelogger;

import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import com.pulseoftheforsaken.client.gui.ArchamConsentScreen;

@Mod.EventBusSubscriber
public class NotesManager {
    private static boolean isInitialized = false;
    private static final List<String> notes = new ArrayList<>();
    private static final String NOTES_FILE = "pulse_notes.txt";
    private static final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public static void initialize() {
        if (!isInitialized) {
            isInitialized = true;
            loadNotes();
        }
    }

    private static void loadNotes() {
        File file = new File(NOTES_FILE);
        if (file.exists()) {
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
                lock.writeLock().lock();
                try {
                    notes.clear();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        notes.add(line);
                    }
                } finally {
                    lock.writeLock().unlock();
                }
            } catch (IOException e) {
                System.err.println("Błąd podczas ładowania notatek: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    public static void addNote(String note) {
        String timestamp = LocalDateTime.now().format(DATE_FORMAT);
        String formattedNote = String.format("[%s] %s", timestamp, note);
        
        lock.writeLock().lock();
        try {
            notes.add(formattedNote);
            saveNotes();
        } finally {
            lock.writeLock().unlock();
        }
    }

    private static void saveNotes() {
        try (BufferedWriter writer = new BufferedWriter(
                new OutputStreamWriter(new FileOutputStream(NOTES_FILE), StandardCharsets.UTF_8))) {
            lock.readLock().lock();
            try {
                for (String note : notes) {
                    writer.write(note);
                    writer.newLine();
                }
            } finally {
                lock.readLock().unlock();
            }
        } catch (IOException e) {
            System.err.println("Błąd podczas zapisywania notatek: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static List<String> getNotes() {
        lock.readLock().lock();
        try {
            return new ArrayList<>(notes);
        } finally {
            lock.readLock().unlock();
        }
    }

    public static void clearNotes() {
        lock.writeLock().lock();
        try {
            notes.clear();
            saveNotes();
        } finally {
            lock.writeLock().unlock();
        }
    }

    public static void cleanup() {
        clearNotes();
        File file = new File(NOTES_FILE);
        if (file.exists()) {
            file.delete();
        }
    }

    @SubscribeEvent
    public static void onScreenOpen(ScreenEvent.Opening event) {
        if (event.getNewScreen() != null && !(event.getNewScreen() instanceof ArchamConsentScreen)) {
            lock.readLock().lock();
            try {
                if (!notes.isEmpty()) {
                    event.setCanceled(true);
                    Minecraft.getInstance().setScreen(new NotesScreen());
                }
            } finally {
                lock.readLock().unlock();
            }
        }
    }

    private static class NotesScreen extends Screen {
        private static final int MAX_NOTES_PER_PAGE = 10;
        private int currentPage = 0;
        private List<String> displayedNotes;

        protected NotesScreen() {
            super(Component.literal("Pulse Notes"));
            displayedNotes = getNotes();
        }

        @Override
        public void render(net.minecraft.client.gui.GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
            this.renderBackground(graphics);
            
            int y = 20;
            int startIndex = currentPage * MAX_NOTES_PER_PAGE;
            int endIndex = Math.min(startIndex + MAX_NOTES_PER_PAGE, displayedNotes.size());
            
            for (int i = startIndex; i < endIndex; i++) {
                String note = displayedNotes.get(i);
                graphics.drawString(this.font, note, 10, y, 0xFFFFFF);
                y += 12;
            }

            // Rysowanie nawigacji stron
            if (displayedNotes.size() > MAX_NOTES_PER_PAGE) {
                String pageText = String.format("Strona %d/%d", currentPage + 1, 
                    (displayedNotes.size() - 1) / MAX_NOTES_PER_PAGE + 1);
                graphics.drawString(this.font, pageText, 
                    this.width - this.font.width(pageText) - 10, 
                    this.height - 20, 0xFFFFFF);
            }

            super.render(graphics, mouseX, mouseY, partialTicks);
        }

        @Override
        public boolean mouseClicked(double mouseX, double mouseY, int button) {
            if (button == 0) { // Lewy przycisk myszy
                if (mouseY > this.height - 30 && mouseY < this.height - 10) {
                    if (mouseX < this.width / 2) {
                        // Poprzednia strona
                        if (currentPage > 0) currentPage--;
                    } else {
                        // Następna strona
                        if ((currentPage + 1) * MAX_NOTES_PER_PAGE < displayedNotes.size()) {
                            currentPage++;
                        }
                    }
                }
            }
            return super.mouseClicked(mouseX, mouseY, button);
        }

        @Override
        public boolean isPauseScreen() {
            return true;
        }
    }
} 