package com.pulseoftheforsaken.simplelogger;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.util.RandomSource;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * Klasa obsługująca efekt matrixowy (spadające cyfry)
 */
public class MatrixEffect {
    private static final RandomSource random = RandomSource.create();
    private static boolean isMatrixActive = false;
    private static int matrixDuration = 0;
    private static final int MATRIX_DURATION = 20; // 1 sekunda (20 ticków/s)
    private static final List<MatrixColumn> columns = new ArrayList<>();
    private static final String MATRIX_CHARS = "0123456789";
    
    /**
     * Klasa reprezentująca kolumnę spadających cyfr
     */
    private static class MatrixColumn {
        public final int x;
        public int y;
        public final int speed;
        public final List<Character> chars;
        
        public MatrixColumn(int x, int speed) {
            this.x = x;
            this.y = 0;
            this.speed = speed;
            this.chars = new ArrayList<>();
            // Dodaj losowe cyfry
            for (int i = 0; i < 10; i++) {
                chars.add(MATRIX_CHARS.charAt(random.nextInt(MATRIX_CHARS.length())));
            }
        }
        
        public void update() {
            y += speed;
            // Losowo zmień niektóre cyfry
            if (random.nextInt(5) == 0) {
                int index = random.nextInt(chars.size());
                chars.set(index, MATRIX_CHARS.charAt(random.nextInt(MATRIX_CHARS.length())));
            }
        }
    }
    
    /**
     * Aktywuje efekt matrixowy
     */
    public static void activateMatrixEffect() {
        isMatrixActive = true;
        matrixDuration = MATRIX_DURATION;
        columns.clear();
        
        // Utwórz kolumny
        Minecraft minecraft = Minecraft.getInstance();
        int width = minecraft.getWindow().getGuiScaledWidth();
        int numColumns = width / 20; // Kolumna co 20 pikseli
        
        for (int i = 0; i < numColumns; i++) {
            columns.add(new MatrixColumn(i * 20, random.nextInt(2, 5)));
        }
    }
    
    /**
     * Aktualizuje stan efektu matrixowego
     */
    public static void update() {
        if (!isMatrixActive) return;
        
        matrixDuration--;
        
        // Aktualizuj kolumny
        for (MatrixColumn column : columns) {
            column.update();
        }
        
        // Zakończ efekt
        if (matrixDuration <= 0) {
            isMatrixActive = false;
            columns.clear();
        }
    }
    
    /**
     * Renderuje efekt matrixowy
     */
    @SubscribeEvent
    public static void onRenderOverlay(RenderGuiOverlayEvent.Post event) {
        if (!isMatrixActive) return;
        
        GuiGraphics guiGraphics = event.getGuiGraphics();
        int height = guiGraphics.guiHeight();
        
        // Renderuj każdą kolumnę
        for (MatrixColumn column : columns) {
            for (int i = 0; i < column.chars.size(); i++) {
                int y = column.y + i * 20;
                if (y >= 0 && y < height) {
                    // Losowy kolor (zielony odcienie)
                    int color = 0xFF00FF00 + random.nextInt(0x0000FF00);
                    guiGraphics.drawString(Minecraft.getInstance().font,
                        String.valueOf(column.chars.get(i)),
                        column.x, y,
                        color);
                }
            }
        }
    }
    
    /**
     * Sprawdza, czy efekt matrixowy jest aktywny
     */
    public static boolean isMatrixActive() {
        return isMatrixActive;
    }
} 