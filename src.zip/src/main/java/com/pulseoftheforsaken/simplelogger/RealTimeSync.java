package com.pulseoftheforsaken.simplelogger;

import net.minecraft.client.Minecraft;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;

public class RealTimeSync {
    private static RealTimeSync instance;
    private final RandomSource random = RandomSource.create();
    private int lastHour = -1;
    private int lastMinute = -1;
    
    private RealTimeSync() {}
    
    public static RealTimeSync getInstance() {
        if (instance == null) {
            instance = new RealTimeSync();
        }
        return instance;
    }
    
    public void update() {
        if (!HorrorHUDManager.getInstance().isEnabled()) return;
        
        int currentHour = java.time.LocalTime.now().getHour();
        int currentMinute = java.time.LocalTime.now().getMinute();
        
        // Sprawdź zmianę godziny
        if (currentHour != lastHour) {
            handleHourChange(currentHour);
            lastHour = currentHour;
        }
        
        // Sprawdź zmianę minuty
        if (currentMinute != lastMinute) {
            handleMinuteChange(currentMinute);
            lastMinute = currentMinute;
        }
        
        // Losowe efekty w zależności od pory dnia
        if (currentHour >= 22 || currentHour < 6) {
            // Noc - częstsze efekty
            if (random.nextInt(1000) == 0) {
                triggerNightEffect();
            }
        } else if (currentHour >= 6 && currentHour < 12) {
            // Poranek - rzadsze efekty
            if (random.nextInt(2000) == 0) {
                triggerMorningEffect();
            }
        } else if (currentHour >= 12 && currentHour < 18) {
            // Dzień - bardzo rzadkie efekty
            if (random.nextInt(3000) == 0) {
                triggerDayEffect();
            }
        } else {
            // Wieczór - średnia częstotliwość efektów
            if (random.nextInt(1500) == 0) {
                triggerEveningEffect();
            }
        }
    }
    
    private void handleHourChange(int hour) {
        if (hour == 0) {
            // Północ - specjalny efekt
            triggerMidnightEffect();
        } else if (hour == 3) {
            // Godzina duchów
            triggerWitchingHourEffect();
        } else if (hour == 6) {
            // Świt
            triggerDawnEffect();
        } else if (hour == 12) {
            // Południe
            triggerNoonEffect();
        } else if (hour == 18) {
            // Zmierzch
            triggerDuskEffect();
        }
    }
    
    private void handleMinuteChange(int minute) {
        if (minute == 0) {
            // Pełna godzina
            triggerHourlyEffect();
        } else if (minute == 30) {
            // Pół godziny
            triggerHalfHourEffect();
        }
    }
    
    private void triggerNightEffect() {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player != null) {
            minecraft.player.playSound(SoundEvents.AMBIENT_CAVE.get(), 0.3F, 0.5F);
            HorrorHUDManager.getInstance().triggerGlitchEffect();
        }
    }
    
    private void triggerMorningEffect() {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player != null) {
            minecraft.player.playSound(SoundEvents.AMBIENT_CAVE.get(), 0.2F, 1.0F);
        }
    }
    
    private void triggerDayEffect() {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player != null) {
            minecraft.player.playSound(SoundEvents.AMBIENT_CAVE.get(), 0.1F, 1.5F);
        }
    }
    
    private void triggerEveningEffect() {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player != null) {
            minecraft.player.playSound(SoundEvents.AMBIENT_CAVE.get(), 0.25F, 0.8F);
            HorrorHUDManager.getInstance().triggerWhisper();
        }
    }
    
    private void triggerMidnightEffect() {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player != null) {
            minecraft.player.playSound(SoundEvents.AMBIENT_CAVE.get(), 0.5F, 0.3F);
            HorrorHUDManager.getInstance().triggerGlitchEffect();
            HorrorHUDManager.getInstance().triggerWhisper();
        }
    }
    
    private void triggerWitchingHourEffect() {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player != null) {
            minecraft.player.playSound(SoundEvents.AMBIENT_CAVE.get(), 0.4F, 0.4F);
            HorrorHUDManager.getInstance().triggerFakeError();
        }
    }
    
    private void triggerDawnEffect() {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player != null) {
            minecraft.player.playSound(SoundEvents.AMBIENT_CAVE.get(), 0.3F, 1.2F);
        }
    }
    
    private void triggerNoonEffect() {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player != null) {
            minecraft.player.playSound(SoundEvents.AMBIENT_CAVE.get(), 0.2F, 1.3F);
        }
    }
    
    private void triggerDuskEffect() {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player != null) {
            minecraft.player.playSound(SoundEvents.AMBIENT_CAVE.get(), 0.35F, 0.7F);
            HorrorHUDManager.getInstance().triggerInputLag();
        }
    }
    
    private void triggerHourlyEffect() {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player != null) {
            minecraft.player.playSound(SoundEvents.AMBIENT_CAVE.get(), 0.3F, 0.6F);
        }
    }
    
    private void triggerHalfHourEffect() {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player != null) {
            minecraft.player.playSound(SoundEvents.AMBIENT_CAVE.get(), 0.2F, 0.9F);
        }
    }
} 