package com.pulseoftheforsaken.simplelogger;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * Klasa obsługująca efekt oczu entity2137 na niebie
 */
public class SkyEyesEffect {
    private static final RandomSource random = RandomSource.create();
    private static boolean isEyesActive = false;
    private static int eyesDuration = 0;
    private static final int EYES_DURATION = 60; // 3 sekundy (20 ticków/s)
    private static final ResourceLocation SKY_EYES_TEXTURE = new ResourceLocation("pulseoftheforsaken", "textures/eye sky.png");
    
    /**
     * Aktywuje efekt oczu na niebie
     */
    public static void activateEyesEffect() {
        isEyesActive = true;
        eyesDuration = EYES_DURATION;
        
        // Wyświetl wiadomość
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player != null) {
            minecraft.player.displayClientMessage(Component.literal("§c§oThe sky is watching..."), true);
        }
    }
    
    /**
     * Aktualizuje stan efektu oczu
     */
    public static void update() {
        if (!isEyesActive) return;
        
        eyesDuration--;
        
        // Zakończ efekt
        if (eyesDuration <= 0) {
            isEyesActive = false;
        }
    }
    
    /**
     * Renderuje oczy na niebie
     */
    @SubscribeEvent
    public static void onRenderOverlay(RenderGuiOverlayEvent.Post event) {
        if (!isEyesActive) return;
        
        GuiGraphics guiGraphics = event.getGuiGraphics();
        int width = guiGraphics.guiWidth();
        int height = guiGraphics.guiHeight();
        
        // Renderuj półprzezroczystą czerwoną nakładkę
        guiGraphics.fill(0, 0, width, height, 0x40FF0000);
        
        // Renderuj teksturę oczu na środku ekranu
        int texSize = Math.min(width, height) / 2;
        int x = width / 2 - texSize / 2;
        int y = height / 3 - texSize / 2;
        guiGraphics.blit(SKY_EYES_TEXTURE, x, y, 0, 0, texSize, texSize, texSize, texSize);
    }
    
    public static boolean isEyesEffectActive() {
        return isEyesActive;
    }
} 