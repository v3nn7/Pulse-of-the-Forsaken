package com.pulseoftheforsaken.simplelogger;

import com.pulseoftheforsaken.simplelogger.util.SimpleLogger;

/**
 * Zarządza finałowym jumpscarem z wideo i zamknięciem rytuału.
 */
public class FinalJumpscareManager {

    private static final String VIDEO_URL = "https://www.youtube.com/watch?v=QH2-TGUlwu4";

    public static void triggerFinalJumpscare() {
        SimpleLogger.info("Wywołano finałowy jumpscare.");
        // TODO: implementacja odtwarzania wideo i zamknięcia rytuału
        SimpleLogger.info("Odtwarzanie wideo: " + VIDEO_URL);
    }

    public static void closeRitual() {
        SimpleLogger.info("Zamknięcie rytuału.");
        // TODO: implementacja zamknięcia rytuału
    }
}
