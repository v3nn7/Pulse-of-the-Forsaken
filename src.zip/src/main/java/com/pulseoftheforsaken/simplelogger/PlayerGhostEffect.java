package com.pulseoftheforsaken.simplelogger;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * Klasa obsługująca efekt ducha gracza po śmierci
 */
public class PlayerGhostEffect {
    private static final RandomSource random = RandomSource.create();
    private static boolean isGhostActive = false;
    private static int ghostDuration = 0;
    private static final int GHOST_DURATION = 600; // 30 sekund (20 ticków/s)
    private static final List<GhostPosition> ghostPositions = new ArrayList<>();
    private static final int MAX_GHOST_POSITIONS = 5;
    
    /**
     * Klasa przechowująca pozycję ducha
     */
    private static class GhostPosition {
        public final double x, y, z;
        public final float yRot, xRot;
        public final int alpha;
        
        public GhostPosition(double x, double y, double z, float yRot, float xRot, int alpha) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.yRot = yRot;
            this.xRot = xRot;
            this.alpha = alpha;
        }
    }
    
    /**
     * Aktywuje efekt ducha po śmierci gracza
     */
    public static void activateGhostEffect() {
        isGhostActive = true;
        ghostDuration = GHOST_DURATION;
        ghostPositions.clear();
        
        // Dodaj początkową pozycję ducha
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player != null) {
            Player player = minecraft.player;
            ghostPositions.add(new GhostPosition(
                player.getX(), player.getY(), player.getZ(),
                player.getYRot(), player.getXRot(),
                128 // Połowiczna przezroczystość
            ));
        }
    }
    
    /**
     * Aktualizuje stan efektu ducha
     */
    public static void update() {
        if (!isGhostActive) return;
        
        ghostDuration--;
        
        // Co 2 sekundy dodaj nową pozycję ducha
        if (ghostDuration % 40 == 0) {
            Minecraft minecraft = Minecraft.getInstance();
            if (minecraft.player != null) {
                Player player = minecraft.player;
                
                // Dodaj nową pozycję
                ghostPositions.add(new GhostPosition(
                    player.getX() + random.nextDouble() * 10 - 5,
                    player.getY(),
                    player.getZ() + random.nextDouble() * 10 - 5,
                    player.getYRot() + random.nextFloat() * 360 - 180,
                    player.getXRot() + random.nextFloat() * 60 - 30,
                    64 // Bardziej przezroczysty
                ));
                
                // Ogranicz liczbę duchów
                if (ghostPositions.size() > MAX_GHOST_POSITIONS) {
                    ghostPositions.remove(0);
                }
            }
        }
        
        // Zakończ efekt
        if (ghostDuration <= 0) {
            isGhostActive = false;
            ghostPositions.clear();
        }
    }
    
    /**
     * Renderuje duchy gracza
     */
    @SubscribeEvent
    public static void onRenderOverlay(RenderGuiOverlayEvent.Post event) {
        if (!isGhostActive || ghostPositions.isEmpty()) return;
        
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null) return;
        
        GuiGraphics guiGraphics = event.getGuiGraphics();
        EntityRenderDispatcher renderManager = minecraft.getEntityRenderDispatcher();
        
        // Renderuj każdą pozycję ducha
        for (GhostPosition ghostPos : ghostPositions) {
            // Renderuj model gracza jako duch
            if (minecraft.player instanceof AbstractClientPlayer) {
                AbstractClientPlayer clientPlayer = (AbstractClientPlayer) minecraft.player;
                PlayerRenderer playerRenderer = (PlayerRenderer) renderManager.getRenderer(clientPlayer);
                
                // Ustaw pozę ducha
                clientPlayer.setYRot(ghostPos.yRot);
                clientPlayer.setXRot(ghostPos.xRot);
                clientPlayer.setPos(ghostPos.x, ghostPos.y, ghostPos.z);
                
                // Renderuj model z przezroczystością
                MultiBufferSource.BufferSource bufferSource = minecraft.renderBuffers().bufferSource();
                playerRenderer.render(clientPlayer, 0, 0, guiGraphics.pose(), bufferSource, ghostPos.alpha);
                bufferSource.endBatch();
            }
        }
    }
} 