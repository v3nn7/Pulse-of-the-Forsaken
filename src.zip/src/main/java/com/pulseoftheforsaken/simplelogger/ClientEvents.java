package com.pulseoftheforsaken.simplelogger;

import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class ClientEvents {

    @SubscribeEvent
    public static void onRenderOverlay(RenderGuiOverlayEvent.Post event) {
        if (!HorrorHUDManager.isEnabled()) return;
        
        // Aktualizacja efektów
        HorrorHUDManager.update();
        PsycheManager.update();
        CursorEffect.update();
        EntityBlinkEffect.update();
        SignWhisperEffect.update();
        
        // Renderowanie efektów
        HorrorHUDManager.render(event.getGuiGraphics());
        PsycheManager.renderPsycheBar(event.getGuiGraphics());
        if (MirrorWorldEffect.isMirrorActive()) {
            MirrorWorldEffect.onRenderOverlay(event);
        }
        if (SkyEyesEffect.isEyesEffectActive()) {
            SkyEyesEffect.onRenderOverlay(event);
        }
        if (GUIEffect.isGUIActive()) {
            GUIEffect.onRenderOverlay(event);
        }
        if (InventoryEffect.isInventoryEffectActive()) {
            // InventoryEffect.onScreenRender(event); // Usunięte, bo zły typ eventu
        }
        if (MatrixEffect.isMatrixActive()) {
            MatrixEffect.onRenderOverlay(event);
        }
        if (HeartbeatEffect.isActive()) {
            HeartbeatEffect.onRenderOverlay(event.getGuiGraphics());
        }
        if (QREffect.isActive()) {
            QREffect.onRenderOverlay(event.getGuiGraphics());
        }
        if (ErrorScreenEffect.isActive()) {
            ErrorScreenEffect.onRenderOverlay(event.getGuiGraphics());
        }
        if (MirrorEffect.isActive()) {
            MirrorEffect.onRenderOverlay(event.getGuiGraphics());
        }
        if (EntityBlinkEffect.isActive()) {
            EntityBlinkEffect.onRenderOverlay(event.getGuiGraphics());
        }
        if (SignWhisperEffect.isActive()) {
            SignWhisperEffect.onRenderOverlay(event.getGuiGraphics());
        }
        if (QREffect2.isActive()) {
            QREffect2.onRenderOverlay(event.getGuiGraphics());
        }
        // Obrót HUD jeśli efekt lustra aktywny
        if (MirrorEffect.isHudFlipped()) {
            event.getGuiGraphics().pose().pushPose();
            int width = event.getGuiGraphics().guiWidth();
            int height = event.getGuiGraphics().guiHeight();
            event.getGuiGraphics().pose().translate(width / 2, height / 2, 0);
            event.getGuiGraphics().pose().scale(1, -1, 1);
            event.getGuiGraphics().pose().translate(-width / 2, -height / 2, 0);
        }
        if (MirrorEffect.isHudFlipped()) {
            event.getGuiGraphics().pose().popPose();
        }
    }
    
    @SubscribeEvent
    public static void onScreenRender(ScreenEvent.Render.Post event) {
        if (!HorrorHUDManager.isEnabled()) return;
        if (InventoryEffect.isInventoryEffectActive()) {
            InventoryEffect.onScreenRender(event);
        }
    }
} 