package com.pulseoftheforsaken.simplelogger;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class MirrorEffect {
    private static final Logger LOGGER = LogManager.getLogger();
    private static final int DURATION = 40; // 2 sekundy (20 ticków/s)
    private static final int HUD_FLIP_DURATION = 200; // 10 sekund
    private static final ResourceLocation MIRROR_TEXTURE = new ResourceLocation("pulseoftheforsaken", "textures/reflection_idle.png");
    private static boolean active = false;
    private static int timer = 0;
    private static boolean hudFlipped = false;
    private static int hudFlipTimer = 0;
    private static final String[] MESSAGES = {
        "It remembered you.",
        "You are not alone.",
        "The mirror sees everything.",
        "Your reflection is watching..."
    };

    public static void activate() {
        LOGGER.info("Activating mirror effect");
        active = true;
        timer = DURATION;
        // Dźwięk szeptu
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            LOGGER.info("Playing whisper sound");
            mc.player.playSound(
                SoundEvent.createVariableRangeEvent(
                    new ResourceLocation("pulseoftheforsaken", "whisper_loop")
                ),
                1.0F, 1.0F
            );
            // Nakładam efekt Slowness V na 2 sekundy
            LOGGER.info("Applying slowness effect");
            mc.player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, DURATION, 4, false, false, false));
        }
    }

    public static void update() {
        if (active) {
            timer--;
            LOGGER.debug("Mirror effect timer: {}", timer);
            if (timer <= 0) {
                LOGGER.info("Mirror effect timer expired, activating HUD flip");
                active = false;
                hudFlipped = true;
                hudFlipTimer = HUD_FLIP_DURATION;
                // Losowa wiadomość
                Minecraft mc = Minecraft.getInstance();
                if (mc.player != null) {
                    String msg = MESSAGES[(int)(Math.random() * MESSAGES.length)];
                    LOGGER.info("Displaying mirror message: {}", msg);
                    mc.player.displayClientMessage(net.minecraft.network.chat.Component.literal("§c§o" + msg), false);
                }
            }
        }
        if (hudFlipped) {
            hudFlipTimer--;
            LOGGER.debug("HUD flip timer: {}", hudFlipTimer);
            if (hudFlipTimer <= 0) {
                LOGGER.info("HUD flip timer expired, disabling flip");
                hudFlipped = false;
            }
        }
    }

    public static void onRenderOverlay(GuiGraphics guiGraphics) {
        if (active) {
            LOGGER.debug("Rendering mirror overlay");
            int width = guiGraphics.guiWidth();
            int height = guiGraphics.guiHeight();
            guiGraphics.blit(MIRROR_TEXTURE, 0, 0, 0, 0, width, height, width, height);
        }
    }

    public static boolean isActive() {
        return active;
    }
    
    public static boolean isHudFlipped() {
        return hudFlipped;
    }
} 