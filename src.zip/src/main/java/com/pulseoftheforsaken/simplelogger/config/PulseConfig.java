package com.pulseoftheforsaken.simplelogger.config;

import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.config.ModConfig;
import org.apache.commons.lang3.tuple.Pair;

public class PulseConfig {
    private static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();
    public static final ForgeConfigSpec COMMON_SPEC;
    public static final PulseConfig COMMON;
    
    public final ForgeConfigSpec.BooleanValue enableConsentScreen;
    public final ForgeConfigSpec.BooleanValue enableHorrorEffects;
    public final ForgeConfigSpec.BooleanValue enableRealTimeSync;
    public final ForgeConfigSpec.BooleanValue enablePlayerDataReveal;
    public final ForgeConfigSpec.IntValue effectIntensity;
    public final ForgeConfigSpec.IntValue effectFrequency;
    public final ForgeConfigSpec.BooleanValue logCommandEvents;
    public final ForgeConfigSpec.BooleanValue logPlayerEvents;
    public final ForgeConfigSpec.BooleanValue acceptedConsent;
    
    private PulseConfig(ForgeConfigSpec.Builder builder) {
        builder.push("Pulse of the Forsaken Configuration");
        
        enableConsentScreen = builder
            .comment("Show consent screen on startup")
            .define("enableConsentScreen", true);
            
        enableHorrorEffects = builder
            .comment("Enable horror effects")
            .define("enableHorrorEffects", true);
            
        enableRealTimeSync = builder
            .comment("Synchronize effects with real time")
            .define("enableRealTimeSync", true);
            
        enablePlayerDataReveal = builder
            .comment("Enable player data reveal")
            .define("enablePlayerDataReveal", true);
            
        effectIntensity = builder
            .comment("Effect intensity (1-10)")
            .defineInRange("effectIntensity", 5, 1, 10);
            
        effectFrequency = builder
            .comment("Effect frequency (1-10)")
            .defineInRange("effectFrequency", 5, 1, 10);
            
        logCommandEvents = builder
            .comment("Log command events")
            .define("logCommandEvents", true);
            
        logPlayerEvents = builder
            .comment("Log player events")
            .define("logPlayerEvents", true);
        
        acceptedConsent = builder
            .comment("Has the user accepted the mod's consent screen?")
            .define("acceptedConsent", false);
            
        builder.pop();
    }
    
    static {
        final Pair<PulseConfig, ForgeConfigSpec> specPair = new ForgeConfigSpec.Builder()
            .configure(PulseConfig::new);
        COMMON = specPair.getLeft();
        COMMON_SPEC = specPair.getRight();
    }
    
    public static void register() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, COMMON_SPEC);
    }
    
    public static boolean isConsentScreenEnabled() {
        return COMMON.enableConsentScreen.get();
    }
    
    public static boolean areHorrorEffectsEnabled() {
        return COMMON.enableHorrorEffects.get();
    }
    
    public static boolean isRealTimeSyncEnabled() {
        return COMMON.enableRealTimeSync.get();
    }
    
    public static boolean isPlayerDataRevealEnabled() {
        return COMMON.enablePlayerDataReveal.get();
    }
    
    public static int getEffectIntensity() {
        return COMMON.effectIntensity.get();
    }
    
    public static int getEffectFrequency() {
        return COMMON.effectFrequency.get();
    }
    
    public static boolean areCommandEventsLogged() {
        return COMMON.logCommandEvents.get();
    }
    
    public static boolean arePlayerEventsLogged() {
        return COMMON.logPlayerEvents.get();
    }
    
    public static boolean isConsentAccepted() {
        return COMMON.acceptedConsent.get();
    }
}