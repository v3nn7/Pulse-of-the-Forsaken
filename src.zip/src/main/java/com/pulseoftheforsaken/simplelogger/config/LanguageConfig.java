package com.pulseoftheforsaken.simplelogger.config;

import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.config.ModConfig;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LanguageConfig {
    private static final Logger LOGGER = LogManager.getLogger();
    public static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.EnumValue<Language> LANGUAGE;

    static {
        BUILDER.push("Language Settings");
        
        LANGUAGE = BUILDER.comment("Select mod language (en_us, pl_pl, or sl_sl)")
                         .defineEnum("language", Language.ENGLISH);
        
        BUILDER.pop();
        SPEC = BUILDER.build();
    }

    public static void register() {
        try {
            ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, SPEC, "pulseoftheforsaken-language.toml");
            LOGGER.info("LanguageConfig registered successfully");
        } catch (Exception e) {
            LOGGER.error("Failed to register LanguageConfig: {}", e.getMessage());
            e.printStackTrace();
        }
    }

    public enum Language {
        ENGLISH("en_us"),
        POLISH("pl_pl"),
        SLAVIC("sl_sl");

        private final String code;

        Language(String code) {
            this.code = code;
        }

        public String getCode() {
            return code;
        }
    }

    public static boolean isPolish() {
        return LANGUAGE.get() == Language.POLISH;
    }

    public static boolean isSlavic() {
        return LANGUAGE.get() == Language.SLAVIC;
    }
} 