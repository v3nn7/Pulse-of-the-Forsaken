package com.pulseoftheforsaken.simplelogger;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.Minecraft;

public class QREffect {
    private static final int DURATION = 300; // 15 sekund (20 ticków/s)
    private static final ResourceLocation QR_TEXTURE = new ResourceLocation("pulseoftheforsaken", "textures/qr_pulse_pastebin.png");
    private static boolean active = false;
    private static int timer = 0;

    public static void activate() {
        active = true;
        timer = DURATION;
        // Odtwórz dźwięk QR
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            mc.player.playSound(
                net.minecraft.sounds.SoundEvent.createVariableRangeEvent(
                    new net.minecraft.resources.ResourceLocation("pulseoftheforsaken", "scan_ping")
                ),
                1.0F, 1.0F
            );
        }
    }

    public static void update() {
        if (!active) return;
        timer--;
        if (timer <= 0) {
            active = false;
        }
    }

    public static void onRenderOverlay(GuiGraphics guiGraphics) {
        if (!active) return;
        int width = guiGraphics.guiWidth();
        int height = guiGraphics.guiHeight();
        int texSize = Math.min(width, height) / 3;
        int x = width / 2 - texSize / 2;
        int y = height / 2 - texSize / 2;
        guiGraphics.blit(QR_TEXTURE, x, y, 0, 0, texSize, texSize, texSize, texSize);
    }

    public static boolean isActive() {
        return active;
    }
} 