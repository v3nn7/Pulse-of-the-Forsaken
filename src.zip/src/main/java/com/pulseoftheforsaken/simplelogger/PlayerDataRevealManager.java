package com.pulseoftheforsaken.simplelogger;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.level.block.entity.SignText;
import com.pulseoftheforsaken.simplelogger.util.SimpleLogger;
import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.time.Instant;
import java.util.*;
import net.minecraft.world.item.DyeColor;
import net.minecraft.client.Minecraft;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
/**
 * Manages gradual player data revelation over successive days.
 */
public class PlayerDataRevealManager {
    private static final Map<UUID, Instant> playerJoinTimes = new HashMap<>();
    private static final Map<UUID, Integer> playerRevealStage = new HashMap<>();
    private static final Map<UUID, Long> playerLastTickCount = new HashMap<>();
    private static final int TICKS_PER_DAY = 24000; // Minecraft day has 24000 ticks
    // Constants for revelation stages
    public static final int STAGE_INITIAL = 0;
    public static final int STAGE_NICK_COUNTRY = 1;
    public static final int STAGE_CITY_GLITCH = 2;
    public static final int STAGE_FULL_DATA = 3;
    // Sign locations
    private static final List<BlockPos> signLocations = new ArrayList<>();
    private static PlayerDataRevealManager instance;
    private final RandomSource random = RandomSource.create();
    private int currentStage = 0;
    private int ticksPassed = 0;
    private static final int TICKS_PER_STAGE = 12000; // 10 minut
    
    private PlayerDataRevealManager() {}
    
    public static PlayerDataRevealManager getInstance() {
        if (instance == null) {
            instance = new PlayerDataRevealManager();
        }
        return instance;
    }
    
    /**
     * Registers the time of player's first join.
     */
    public static void registerPlayerJoin(Player player) {
        UUID playerId = player.getUUID();
        if (!playerJoinTimes.containsKey(playerId)) {
            playerJoinTimes.put(playerId, Instant.now());
            playerRevealStage.put(playerId, STAGE_INITIAL);
            playerLastTickCount.put(playerId, 0L);
            // Add mysterious message in chat
            player.sendSystemMessage(Component.literal("§7entity2137 joined to the world"));
            SimpleLogger.info("Registered join time for player " + player.getName().getString());
        }
    }
    /**
     * Updates the data revelation stage based on tick count.
     * Should be called in player tick event.
     */
    public static void updatePlayerRevealStage(Player player, long currentTick) {
        UUID playerId = player.getUUID();
        if (!playerJoinTimes.containsKey(playerId)) {
            return;
        }
        long lastTick = playerLastTickCount.getOrDefault(playerId, 0L);
        int currentStage = playerRevealStage.getOrDefault(playerId, STAGE_INITIAL);
        // Update tick counter
        playerLastTickCount.put(playerId, currentTick);
        // Calculate ticks passed since join
        long ticksPassed = currentTick - lastTick;
        // Check if we should advance to next stage
        if (currentStage == STAGE_INITIAL && ticksPassed >= TICKS_PER_DAY) {
            // Advance to stage 1 - Username and country
            playerRevealStage.put(playerId, STAGE_NICK_COUNTRY);
            revealStage1(player);
            SimpleLogger.info("Player " + player.getName().getString() + " advanced to data revelation stage 1");
        } 
        else if (currentStage == STAGE_NICK_COUNTRY && ticksPassed >= TICKS_PER_DAY * 2) {
            // Advance to stage 2 - City and glitch effects
            playerRevealStage.put(playerId, STAGE_CITY_GLITCH);
            revealStage2(player);
            SimpleLogger.info("Player " + player.getName().getString() + " advanced to data revelation stage 2");
            // Enable glitch and heartbeat effects
            HorrorHUDManager.enable();
            HorrorHUDManager.triggerGlitchEffect();
            // TODO: implementacja triggerHeartbeat w HorrorHUDManager
        } 
        else if (currentStage == STAGE_CITY_GLITCH && ticksPassed >= TICKS_PER_DAY * 3) {
            // Advance to stage 3 - Full data
            playerRevealStage.put(playerId, STAGE_FULL_DATA);
            revealStage3(player);
            SimpleLogger.info("Player " + player.getName().getString() + " advanced to data revelation stage 3");
            // Launch chapter files and change wallpaper
            launchChapterFiles();
            changeWallpaper();
            // Enable local monitoring
            LocalMonitoringManager.enable();
        }
    }
    /**
     * Gets the current revelation stage for a player.
     */
    public static int getRevealStage(Player player) {
        UUID playerId = player.getUUID();
        return playerRevealStage.getOrDefault(playerId, STAGE_INITIAL);
    }
    /**
     * Gets data to reveal based on stage.
     */
    public static String getDataToReveal(Player player) {
        int stage = getRevealStage(player);
        StringBuilder data = new StringBuilder();
        if (stage >= STAGE_NICK_COUNTRY) {
            data.append("Username: ").append(player.getName().getString()).append("\n");
            data.append("Country: ").append(getCountryForPlayer(player)).append("\n");
        }
        if (stage >= STAGE_CITY_GLITCH) {
            data.append("City: ").append(getCityForPlayer(player)).append("\n");
            data.append("Glitch and heartbeat effects active\n");
        }
        if (stage >= STAGE_FULL_DATA) {
            data.append("Street: ").append(getStreetForPlayer(player)).append("\n");
            data.append("Full IP: ").append(getFullIPForPlayer(player)).append("\n");
            data.append("Chapter files launched and wallpaper changed\n");
            data.append("Local monitoring active\n");
        }
        return data.toString();
    }
    /**
     * Stage 1 revelation - Username and country
     */
    private static void revealStage1(Player player) {
        // Find place for sign
        BlockPos signPos = findPlaceForSign(player);
        if (signPos != null) {
            placeSign(player.level(), signPos, new String[]{
                "§4I AM WATCHING YOU",
                player.getName().getString(),
                getCountryForPlayer(player),
                "§8entity2137"
            });
            signLocations.add(signPos);
        }
        // Send message in chat
        player.sendSystemMessage(Component.literal("§7You feel like someone is watching you..."));
    }
    /**
     * Stage 2 revelation - City and glitch effects
     */
    private static void revealStage2(Player player) {
        // Find place for sign
        BlockPos signPos = findPlaceForSign(player);
        if (signPos != null) {
            placeSign(player.level(), signPos, new String[]{
                "§4I SEE YOU",
                getCityForPlayer(player),
                "§kI will find you",
                "§8entity2137"
            });
            signLocations.add(signPos);
        }
        // Send message in chat
        player.sendSystemMessage(Component.literal("§7You hear strange whispers..."));
        player.sendSystemMessage(Component.literal("§4§kGlitch effect activated"));
    }
    /**
     * Stage 3 revelation - Full data
     */
    private static void revealStage3(Player player) {
        // Find place for sign
        BlockPos signPos = findPlaceForSign(player);
        if (signPos != null) {
            placeSign(player.level(), signPos, new String[]{
                "§4I AM COMING",
                getStreetForPlayer(player),
                getFullIPForPlayer(player),
                "§8entity2137"
            });
            signLocations.add(signPos);
        }
        // Send message in chat
        player.sendSystemMessage(Component.literal("§4Your data has been revealed."));
        player.sendSystemMessage(Component.literal("§7Check your desktop..."));
    }
    /**
     * Finds a suitable place to place a sign near the player.
     */
    private static BlockPos findPlaceForSign(Player player) {
        Level level = player.level();
        BlockPos playerPos = player.blockPosition();
        // Search for a place within 10 blocks radius
        for (int x = -10; x <= 10; x++) {
            for (int y = -3; y <= 3; y++) {
                for (int z = -10; z <= 10; z++) {
                    BlockPos pos = playerPos.offset(x, y, z);
                    BlockState state = level.getBlockState(pos);
                    // Check if block is air and has solid block below
                    if (state.isAir() && level.getBlockState(pos.below()).isSolid()) {
                        return pos;
                    }
                }
            }
        }
        // If no suitable place found, return null
        return null;
    }
    /**
     * Places a sign with given text.
     */
    private static void placeSign(Level level, BlockPos pos, String[] lines) {
        // Set the sign
        level.setBlock(pos, Blocks.OAK_SIGN.defaultBlockState(), 3);
        // Get sign entity
        BlockEntity blockEntity = level.getBlockEntity(pos);
        if (blockEntity instanceof SignBlockEntity sign) {
            // Przygotuj tablicę Component
            Component[] components = new Component[4];
            for (int i = 0; i < 4; i++) {
                if (i < lines.length) {
                    components[i] = Component.literal(lines[i]);
                } else {
                    components[i] = Component.empty();
                }
            }
            // Ustaw tekst na froncie tabliczki
            SignText signText = new SignText(components, null, DyeColor.BLACK, false);
            sign.setText(signText, true); // true = front
            // Update sign
            level.sendBlockUpdated(pos, level.getBlockState(pos), level.getBlockState(pos), 3);
        }
    }
    /**
     * Launches chapter files.
     */
    private static void launchChapterFiles() {
        try {
            // Create chapter files if they don't exist yet
            PuzzleFileManager.createDesktopChapterFiles();
            // Open first chapter file
            File chapter1File = new File(PuzzleFileManager.CHAPTER1_FILE);
            if (chapter1File.exists()) {
                Desktop.getDesktop().open(chapter1File);
                SimpleLogger.info("Launched chapter 1 file");
            }
        } catch (IOException e) {
            SimpleLogger.error("Error launching chapter files: " + e.getMessage());
        }
    }
    /**
     * Changes desktop wallpaper.
     */
    private static void changeWallpaper() {
        // This function will be implemented in LocalMonitoringManager
        // TODO: implementacja changeWallpaper w LocalMonitoringManager
        // Placeholder call removed to fix compilation error
    }
    // Helper methods for getting data
    /**
     * Gets player's country based on IP.
     */
    private static String getCountryForPlayer(Player player) {
        try {
            // In a real implementation, we could use a geolocation API
            // For now, return a constant value
            return "United States";
        } catch (Exception e) {
            return "Unknown";
        }
    }
    /**
     * Gets player's city based on IP.
     */
    private static String getCityForPlayer(Player player) {
        try {
            // In a real implementation, we could use a geolocation API
            // For now, return a constant value
            return "New York";
        } catch (Exception e) {
            return "Unknown";
        }
    }
    /**
     * Gets player's street based on IP.
     */
    private static String getStreetForPlayer(Player player) {
        try {
            // In a real implementation, we could use a geolocation API
            // For now, return a constant value
            return "Example Street 123";
        } catch (Exception e) {
            return "Unknown";
        }
    }
    /**
     * Gets player's IP.
     */
    private static String getFullIPForPlayer(Player player) {
        try {
            // In a real implementation, we could use the connection's IP address
            // For now, return local IP address
            InetAddress localHost = InetAddress.getLocalHost();
            return localHost.getHostAddress();
        } catch (UnknownHostException e) {
            return "192.168.1.100"; // Default value
        }
    }
    /**
     * Calculates puzzle code based on player's IP.
     */
    public static String calculatePuzzleCode(Player player) {
        String ip = getFullIPForPlayer(player);
        int sum = 0;
        // Sum digits in IP address
        for (char c : ip.toCharArray()) {
            if (Character.isDigit(c)) {
                sum += Character.getNumericValue(c);
            }
        }
        // Return sum as code
        return String.valueOf(sum);
    }
    public void update() {
        if (ticksPassed++ >= TICKS_PER_STAGE) {
            ticksPassed = 0;
            advanceStage();
        }
    }
    
    private void advanceStage() {
        currentStage++;
        triggerStageEffect();
    }
    
    private void triggerStageEffect() {
        if (currentStage > 0) {
            HorrorHUDManager.getInstance().triggerGlitchEffect();
            if (random.nextBoolean()) {
                HorrorHUDManager.getInstance().triggerWhisper();
            } else {
                HorrorHUDManager.getInstance().triggerFakeError();
            }
        }
    }
    
    public int getCurrentStage() {
        return currentStage;
    }
    
    public void reset() {
        currentStage = 0;
        ticksPassed = 0;
    }
}
