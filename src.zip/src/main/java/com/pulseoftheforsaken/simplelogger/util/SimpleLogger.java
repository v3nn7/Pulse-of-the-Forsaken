package com.pulseoftheforsaken.simplelogger.util;

import com.pulseoftheforsaken.simplelogger.config.PulseConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Prosty logger, który integruje się z Minecraft
 */
public class SimpleLogger {
    private static final Logger LOGGER = LogManager.getLogger("SimpleLogger");
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private static final String DEFAULT_LOG_FILENAME = "simple.log";
    private static File logFile;
    private static boolean initialized = false;
    private static boolean initializing = false;

    /**
     * Inicjalizuje logger
     */
    public static void init() {
        // Zabezpieczenie przed rekurencją
        if (initialized || initializing) {
            return;
        }
        
        // Ustawiamy flagę, że jesteśmy w trakcie inicjalizacji
        initializing = true;
        
        try {
            // Używamy domyślnej nazwy pliku logu - nie próbujemy uzyskać dostępu do konfiguracji
            String logFileName = DEFAULT_LOG_FILENAME;
            
            // Tworzymy katalog dla logów w katalogu użytkownika
            File logDir = new File(System.getProperty("user.home"), "PulseOfTheForsaken");
            
            // Próbujemy użyć katalogu gry, ale jeśli nie jest dostępny, używamy katalogu użytkownika
            try {
                File gameDir = Minecraft.getInstance().gameDirectory;
                logDir = new File(gameDir, "PulseOfTheForsaken");
            } catch (Exception e) {
                // Ignorujemy błąd, używamy już user.home jako fallback
            }
            
            // Tworzymy katalog, jeśli nie istnieje
            if (!logDir.exists()) {
                logDir.mkdirs();
            }
            
            // Tworzymy plik logu
            logFile = new File(logDir, logFileName);
            if (!logFile.exists()) {
                logFile.createNewFile();
                try (FileWriter writer = new FileWriter(logFile)) {
                    writer.write("=== PULSE OF THE FORSAKEN LOG ===\n\n");
                }
            }
            
            // Oznaczamy, że inicjalizacja zakończyła się sukcesem
            initialized = true;
            initializing = false;
            
            // Logujemy informację o inicjalizacji bezpośrednio do pliku i konsoli
            String timestamp = DATE_FORMAT.format(new Date());
            String logMessage = String.format("[%s] [%s] %s\n", timestamp, "System", "Inicjalizacja loggera");
            
            try (FileWriter writer = new FileWriter(logFile, true)) {
                writer.write(logMessage);
            } catch (IOException e) {
                LOGGER.error("Nie można zapisać do pliku logu: {}", e.getMessage());
            }
            
            LOGGER.info("[System] Inicjalizacja loggera");
        } catch (Exception e) {
            // Oznaczamy, że inicjalizacja zakończyła się niepowodzeniem, ale nie chcemy ponownie próbować
            initialized = true;
            initializing = false;
            LOGGER.error("Nie można zainicjalizować loggera: {}", e.getMessage());
        }
    }

    /**
     * Loguje wiadomość z określonym poziomem
     */
    private static void log(String level, String message) {
        // Jeśli logger nie jest zainicjalizowany, próbujemy go zainicjalizować
        if (!initialized && !initializing) {
            try {
                init();
            } catch (Exception e) {
                // Jeśli inicjalizacja się nie powiedzie, logujemy tylko do konsoli
                LOGGER.info("[{}] {}", level, message);
                return;
            }
        }
        
        // Jeśli inicjalizacja jest w toku, logujemy tylko do konsoli
        if (initializing) {
            LOGGER.info("[{}] {}", level, message);
            return;
        }
        
        // Zawsze logujemy do konsoli
        LOGGER.info("[{}] {}", level, message);
        
        // Loguj do pliku, jeśli plik został utworzony
        if (logFile != null && initialized) {
            try {
                String timestamp = DATE_FORMAT.format(new Date());
                String logMessage = String.format("[%s] [%s] %s\n", timestamp, level, message);
                
                try (FileWriter writer = new FileWriter(logFile, true)) {
                    writer.write(logMessage);
                }
            } catch (Exception e) {
                // Ignoruj błąd, już zalogowaliśmy do konsoli
            }
        }
    }

    /**
     * Loguje informację
     */
    public static void info(String message) {
        log("INFO", message);
    }

    /**
     * Loguje ostrzeżenie
     */
    public static void warn(String message) {
        log("WARN", message);
    }

    /**
     * Loguje błąd
     */
    public static void error(String message) {
        log("ERROR", message);
    }

    /**
     * Loguje błąd z wyjątkiem
     */
    public static void error(String message, Throwable throwable) {
        log("ERROR", message + ": " + throwable.getMessage());
    }
    
    /**
     * Wysyła wiadomość do gracza
     */
    public static void sendMessage(Player player, String message) {
        if (player != null && player.level() != null && !player.level().isClientSide) {
            player.sendSystemMessage(Component.literal("[Pulse of the Forsaken] " + message));
            info("Wysłano wiadomość do gracza " + player.getName().getString() + ": " + message);
        }
    }
}