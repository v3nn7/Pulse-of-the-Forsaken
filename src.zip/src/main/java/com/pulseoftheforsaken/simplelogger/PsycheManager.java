package com.pulseoftheforsaken.simplelogger;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.player.Player;
import net.minecraft.resources.ResourceLocation;

public class PsycheManager {
    private static int psyche = 100; // 0-100
    private static final int MAX_PSYCH = 100;
    private static final int MIN_PSYCH = 0;
    private static final int GLITCH_THRESHOLD = 30;
    private static int psycheDropSoundTimer = 0;

    private static final ResourceLocation[] PSYCHE_BAR_FRAMES = new ResourceLocation[] {
        new ResourceLocation("pulseoftheforsaken", "assets/psyche_bar.png")
        // Dodaj kolejne klatki jeśli są, np. psyche_bar_1.png, psyche_bar_2.png itd.
    };
    private static int psycheBarFrame = 0;
    private static int psycheBarFrameTimer = 0;

    public static int getPsyche() {
        return psyche;
    }

    public static void setPsyche(int value) {
        psyche = Math.max(MIN_PSYCH, Math.min(MAX_PSYCH, value));
    }

    public static void decreasePsyche(int amount) {
        setPsyche(psyche - amount);
    }

    public static void increasePsyche(int amount) {
        setPsyche(psyche + amount);
    }

    public static boolean isLowPsyche() {
        return psyche <= GLITCH_THRESHOLD;
    }

    public static float getPsychePercent() {
        return psyche / (float) MAX_PSYCH;
    }

    // Wywołaj w ticku klienta
    public static void update() {
        // Przykładowy powolny spadek psyche
        if (psyche > MIN_PSYCH && Minecraft.getInstance().level != null && Minecraft.getInstance().player != null) {
            if (Minecraft.getInstance().level.getGameTime() % 200 == 0) { // co 10 sekund
                decreasePsyche(1);
            }
        }
        // Odtwarzaj dźwięk psyche_drop przy niskim psyche co 10 sekund
        if (psyche <= 20) {
            if (psycheDropSoundTimer <= 0) {
                Minecraft mc = Minecraft.getInstance();
                if (mc.player != null) {
                    mc.player.playSound(
                        net.minecraft.sounds.SoundEvent.createVariableRangeEvent(
                            new net.minecraft.resources.ResourceLocation("pulseoftheforsaken", "psyche_drop")
                        ),
                        1.0F, 1.0F
                    );
                }
                psycheDropSoundTimer = 200; // 10 sekund
            } else {
                psycheDropSoundTimer--;
            }
        } else {
            psycheDropSoundTimer = 0;
        }
    }

    // Renderowanie paska psyche na HUDzie
    public static void renderPsycheBar(GuiGraphics guiGraphics) {
        int width = guiGraphics.guiWidth();
        int height = guiGraphics.guiHeight();
        int barWidth = 100;
        int barHeight = 16;
        int x = width / 2 - barWidth / 2;
        int y = height - 30;
        // Animacja paska psyche (jeśli jest więcej klatek)
        if (PSYCHE_BAR_FRAMES.length > 1) {
            if (psycheBarFrameTimer-- <= 0) {
                psycheBarFrame = (psycheBarFrame + 1) % PSYCHE_BAR_FRAMES.length;
                psycheBarFrameTimer = 10;
            }
        }
        ResourceLocation barTexture = PSYCHE_BAR_FRAMES[psycheBarFrame];
        guiGraphics.blit(barTexture, x, y, 0, 0, barWidth, barHeight, barWidth, barHeight);
        // Ramka i napis
        guiGraphics.drawString(Minecraft.getInstance().font, "PSYCHE", x, y - 10, 0xFFFFFFFF);
    }
} 