package com.pulseoftheforsaken.simplelogger;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;

public class EntityBlinkEffect {
    private static final ResourceLocation SHADOW_TEXTURE = new ResourceLocation("pulseoftheforsaken", "assets/entity_shadow.png");
    private static boolean active = false;
    private static int timer = 0;
    private static int nextBlink = 0;

    public static void update() {
        if (PsycheManager.getPsyche() < 20) {
            if (active) {
                timer--;
                if (timer <= 0) {
                    active = false;
                    nextBlink = 200 + (int)(Math.random() * 200); // 10-20 sekund
                }
            } else {
                if (nextBlink > 0) {
                    nextBlink--;
                } else {
                    active = true;
                    timer = 10; // 0.5 sekundy
                }
            }
        } else {
            active = false;
            nextBlink = 100;
        }
    }

    public static void onRenderOverlay(GuiGraphics guiGraphics) {
        if (!active) return;
        int width = guiGraphics.guiWidth();
        int height = guiGraphics.guiHeight();
        guiGraphics.blit(SHADOW_TEXTURE, width / 2 - 64, height / 2 + 40, 0, 0, 128, 128, 128, 128);
    }

    public static boolean isActive() {
        return active;
    }
} 