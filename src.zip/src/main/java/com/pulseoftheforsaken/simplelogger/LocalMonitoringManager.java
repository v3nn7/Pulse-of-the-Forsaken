package com.pulseoftheforsaken.simplelogger;

import com.pulseoftheforsaken.simplelogger.util.SimpleLogger;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import javax.imageio.ImageIO;
import javax.sound.sampled.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Zarządza monitoringiem lokalnym: live-feed z kamerki, miernik mikrofonu, snapshoty zapisywane jako tapeta.
 */
public class LocalMonitoringManager {

    private static boolean enabled = false;
    private static Timer snapshotTimer;
    private static final int SNAPSHOT_INTERVAL = 5000; // 5 seconds
    private static final String SNAPSHOT_FILE = PuzzleFileManager.DESKTOP_PATH + File.separator + "pulse_snapshot.jpg";
    private static final ResourceLocation CAMERA_FRAME = new ResourceLocation("pulseoftheforsaken", "assets/gui/camera_frame.png");
    private static final ResourceLocation MIC_METER = new ResourceLocation("pulseoftheforsaken", "assets/gui/mic_meter.png");
    
    private static TargetDataLine micLine;
    private static float micLevel = 0.0f;
    private static final RandomSource random = RandomSource.create();
    
    // Symulacja kamery (w prawdziwej implementacji użylibyśmy JavaCV lub podobnej biblioteki)
    private static BufferedImage simulatedCameraImage;
    private static int cameraUpdateTicks = 0;

    public static void enable() {
        if (!enabled) {
            enabled = true;
            SimpleLogger.info("Local monitoring enabled.");
            
            // Register events
            MinecraftForge.EVENT_BUS.register(LocalMonitoringManager.class);
            
            // Initialize simulated camera
            initializeSimulatedCamera();
            
            // Initialize microphone
            initializeMicrophone();
            
            // Start snapshot timer
            startSnapshotTimer();
            
            // Update personal log
            PuzzleFileManager.updatePersonalLog("Local monitoring enabled");
        }
    }

    public static void disable() {
        if (enabled) {
            enabled = false;
            SimpleLogger.info("Local monitoring disabled.");
            
            // Unregister events
            MinecraftForge.EVENT_BUS.unregister(LocalMonitoringManager.class);
            
            // Stop snapshot timer
            stopSnapshotTimer();
            
            // Close microphone
            closeMicrophone();
            
            // Update personal log
            PuzzleFileManager.updatePersonalLog("Local monitoring disabled");
        }
    }

    public static boolean isEnabled() {
        return enabled;
    }
    
    /**
     * Inicjalizuje symulowaną kamerę.
     */
    private static void initializeSimulatedCamera() {
        // In a real implementation, we would use JavaCV to capture camera image
        // Here we create a black image as a simulation
        simulatedCameraImage = new BufferedImage(320, 240, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = simulatedCameraImage.createGraphics();
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, 320, 240);
        g.dispose();
        
        SimpleLogger.info("Simulated camera initialized.");
    }
    
    /**
     * Inicjalizuje mikrofon.
     */
    private static void initializeMicrophone() {
        try {
            // Audio format configuration
            AudioFormat format = new AudioFormat(44100, 16, 1, true, false);
            DataLine.Info info = new DataLine.Info(TargetDataLine.class, format);
            
            // Check if the system supports this format
            if (!AudioSystem.isLineSupported(info)) {
                SimpleLogger.error("System does not support the required audio format.");
                return;
            }
            
            // Open microphone line
            micLine = (TargetDataLine) AudioSystem.getLine(info);
            micLine.open(format);
            micLine.start();
            
            SimpleLogger.info("Microphone initialized.");
        } catch (Exception e) {
            SimpleLogger.error("Error initializing microphone: " + e.getMessage());
            // In case of error, we will simulate microphone level
        }
    }
    
    /**
     * Zamyka mikrofon.
     */
    private static void closeMicrophone() {
        if (micLine != null && micLine.isOpen()) {
            micLine.stop();
            micLine.close();
            SimpleLogger.info("Microphone closed.");
        }
    }
    
    /**
     * Uruchamia timer snapshotów.
     */
    private static void startSnapshotTimer() {
        if (snapshotTimer != null) {
            snapshotTimer.cancel();
        }
        
        snapshotTimer = new Timer("SnapshotTimer");
        snapshotTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                takeSnapshot();
            }
        }, SNAPSHOT_INTERVAL, SNAPSHOT_INTERVAL);
        
        SimpleLogger.info("Snapshot timer started.");
    }
    
    /**
     * Zatrzymuje timer snapshotów.
     */
    private static void stopSnapshotTimer() {
        if (snapshotTimer != null) {
            snapshotTimer.cancel();
            snapshotTimer = null;
            SimpleLogger.info("Snapshot timer stopped.");
        }
    }

    /**
     * Aktualizuje obraz z kamery.
     */
    private static void updateCameraFeed() {
        if (!enabled) return;
        
        // W prawdziwej implementacji pobieralibyśmy obraz z kamery
        // Tutaj symulujemy obraz z kamery
        cameraUpdateTicks++;
        
        // Aktualizuj symulowany obraz co 10 ticków
        if (cameraUpdateTicks % 10 == 0) {
            Graphics2D g = simulatedCameraImage.createGraphics();
            
            // Wypełnij tło losowym szumem
            for (int x = 0; x < simulatedCameraImage.getWidth(); x++) {
                for (int y = 0; y < simulatedCameraImage.getHeight(); y++) {
                    int gray = random.nextInt(64);
                    Color color = new Color(gray, gray, gray);
                    simulatedCameraImage.setRGB(x, y, color.getRGB());
                }
            }
            
            // Dodaj losowe kształty symulujące ruch
            g.setColor(new Color(100, 100, 100));
            for (int i = 0; i < 5; i++) {
                int x = random.nextInt(simulatedCameraImage.getWidth());
                int y = random.nextInt(simulatedCameraImage.getHeight());
                int size = random.nextInt(50) + 20;
                g.fillOval(x, y, size, size);
            }
            
            // Dodaj tekst "LIVE"
            g.setColor(Color.RED);
            g.setFont(new Font("Arial", Font.BOLD, 20));
            g.drawString("LIVE", 10, 30);
            
            // Dodaj aktualny czas
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.PLAIN, 12));
            g.drawString(new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date()), 
                    simulatedCameraImage.getWidth() - 150, simulatedCameraImage.getHeight() - 10);
            
            g.dispose();
        }
    }

    /**
     * Aktualizuje poziom mikrofonu.
     */
    private static void updateMicLevel() {
        if (!enabled) return;
        
        if (micLine != null && micLine.isOpen()) {
            // Pobierz dane z mikrofonu
            byte[] buffer = new byte[1024];
            int bytesRead = micLine.read(buffer, 0, buffer.length);
            
            // Oblicz poziom dźwięku
            long sum = 0;
            for (int i = 0; i < bytesRead; i += 2) {
                int sample = (buffer[i] & 0xFF) | ((buffer[i + 1] & 0xFF) << 8);
                if (sample > 32767) sample -= 65536;
                sum += Math.abs(sample);
            }
            
            // Normalizuj poziom dźwięku do zakresu 0.0 - 1.0
            micLevel = (float) sum / (bytesRead / 2) / 32768.0f;
        } else {
            // Symuluj poziom mikrofonu
            micLevel = random.nextFloat() * 0.3f;
        }
    }

    /**
     * Wykonuje snapshot i zapisuje go jako tapetę.
     */
    private static void takeSnapshot() {
        if (!enabled) return;
        
        try {
            // W prawdziwej implementacji zapisalibyśmy obraz z kamery
            // Tutaj zapisujemy symulowany obraz
            File snapshotFile = new File(SNAPSHOT_FILE);
            ImageIO.write(simulatedCameraImage, "jpg", snapshotFile);
            
            // Zmień tapetę
            changeWallpaper();
            
            SimpleLogger.info("Snapshot taken and saved as wallpaper.");
            
            // Update personal log
            PuzzleFileManager.updatePersonalLog("Snapshot taken from camera");
        } catch (IOException e) {
            SimpleLogger.error("Error taking snapshot: " + e.getMessage());
        }
    }
    
    /**
     * Zmienia tapetę na pulpicie.
     */
    public static void changeWallpaper() {
        try {
            // Sprawdź, czy plik snapshotu istnieje
            File snapshotFile = new File(SNAPSHOT_FILE);
            if (!snapshotFile.exists()) {
                SimpleLogger.error("Snapshot file does not exist.");
                return;
            }
            
            // W systemie Windows można użyć SystemParametersInfo do zmiany tapety
            // Tutaj używamy prostej symulacji
            SimpleLogger.info("Wallpaper changed to " + SNAPSHOT_FILE);
            
            // Update personal log
            PuzzleFileManager.updatePersonalLog("Wallpaper changed to snapshot from camera");
        } catch (Exception e) {
            SimpleLogger.error("Error changing wallpaper: " + e.getMessage());
        }
    }
    
    /**
     * Renderuje nakładkę kamery i mikrofonu na HUD.
     */
    @SubscribeEvent
    public static void onRenderOverlay(RenderGuiOverlayEvent.Post event) {
        if (!enabled) return;
        
        Minecraft mc = Minecraft.getInstance();
        GuiGraphics guiGraphics = event.getGuiGraphics();
        int width = mc.getWindow().getGuiScaledWidth();
        int height = mc.getWindow().getGuiScaledHeight();
        
        // Renderuj ramkę kamery w prawym górnym rogu
        int cameraX = width - 110;
        int cameraY = 10;
        int cameraWidth = 100;
        int cameraHeight = 75;
        
        // Tło kamery
        guiGraphics.fill(cameraX, cameraY, cameraX + cameraWidth, cameraY + cameraHeight, 0xAA000000);
        
        // Ramka kamery
        guiGraphics.blit(CAMERA_FRAME, cameraX, cameraY, 0, 0, cameraWidth, cameraHeight, cameraWidth, cameraHeight);
        
        // Tekst "LIVE"
        guiGraphics.drawString(mc.font, "LIVE", cameraX + 5, cameraY + 5, 0xFF0000);
        
        // Renderuj miernik mikrofonu w prawym dolnym rogu
        int micX = width - 110;
        int micY = height - 30;
        int micWidth = 100;
        int micHeight = 20;
        
        // Tło miernika
        guiGraphics.fill(micX, micY, micX + micWidth, micY + micHeight, 0xAA000000);
        
        // Poziom mikrofonu
        int micLevelWidth = (int) (micWidth * micLevel);
        guiGraphics.fill(micX, micY, micX + micLevelWidth, micY + micHeight, 0xAA00FF00);
        
        // Tekst "MIC"
        guiGraphics.drawString(mc.font, "MIC", micX + 5, micY + 5, 0xFFFFFF);
    }
    
    /**
     * Aktualizuje stan monitoringu lokalnego.
     */
    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (!enabled || event.phase != TickEvent.Phase.END) return;
        
        // Aktualizuj obraz z kamery
        updateCameraFeed();
        
        // Aktualizuj poziom mikrofonu
        updateMicLevel();
    }
    
    /**
     * Wyświetla powiadomienie systemowe.
     *
     * @param title Tytuł powiadomienia
     * @param message Treść powiadomienia
     */
    public static void showSystemNotification(String title, String message) {
        try {
            // W prawdziwej implementacji użylibyśmy biblioteki do wyświetlania powiadomień systemowych
            // Tutaj logujemy powiadomienie bezpośrednio do logu Minecraft
            org.apache.logging.log4j.LogManager.getLogger("SimpleLogger").info("System notification: {} - {}", title, message);
            
            // Update personal log
            PuzzleFileManager.updatePersonalLog("Notification: " + title + " - " + message);
        } catch (Exception e) {
            org.apache.logging.log4j.LogManager.getLogger("SimpleLogger").error("Error showing system notification: {}", e.getMessage());
        }
    }
}
