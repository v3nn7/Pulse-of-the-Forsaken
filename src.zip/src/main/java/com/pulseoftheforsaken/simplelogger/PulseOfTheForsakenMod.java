package com.pulseoftheforsaken.simplelogger;

import com.pulseoftheforsaken.simplelogger.commands.LogCommand;
import com.pulseoftheforsaken.simplelogger.commands.PulseCommand;
import com.pulseoftheforsaken.simplelogger.config.PulseConfig;
import com.pulseoftheforsaken.simplelogger.util.SimpleLogger;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent.ClientTickEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.pulseoftheforsaken.simplelogger.ui.AgreeScreen;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Main class of the "Pulse of the Forsaken" mod.
 */
@Mod(PulseOfTheForsakenMod.MOD_ID)
public class PulseOfTheForsakenMod {
    public static final String MOD_ID = "pulseoftheforsaken";
    public static final Logger LOGGER = LogManager.getLogger();
    
    // Rejestr dźwięków
    public static final DeferredRegister<net.minecraft.sounds.SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, MOD_ID);
    
    // Tick counter for each player
    private static final Map<UUID, Long> playerTickCounters = new HashMap<>();
    
    // Random number generator
    private static final Random random = new Random();
    
    // Flag, whether the mod has been accepted
    private static boolean modAccepted = false;

    public PulseOfTheForsakenMod() {
        // Register event handlers
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        modEventBus.addListener(this::setup);
        modEventBus.addListener(this::clientSetup);
        
        // Rejestracja dźwięków
        SOUNDS.register(modEventBus);
        
        // Register config
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, PulseConfig.COMMON_SPEC);
        // Register events
        MinecraftForge.EVENT_BUS.register(this);
        // Initialize SimpleLogger - after config registration
        SimpleLogger.init();
        // Initialize trap files and narration - after logger initialization
        try {
            PuzzleFileManager.initialize();
        } catch (Exception e) {
            LOGGER.error("Error during trap file initialization: " + e.getMessage());
        }
        // Log initialization info
        SimpleLogger.info("Pulse of the Forsaken loaded");
        LOGGER.info("Pulse of the Forsaken: Mod initialized");
    }

    /**
     * Common setup for client and server.
     */
    private void setup(final FMLCommonSetupEvent event) {
        LOGGER.info("Pulse of the Forsaken: Mod setup");
        SimpleLogger.info("Pulse of the Forsaken: Mod setup");
    }
    
    /**
     * Client-side setup only.
     */
    private void clientSetup(final FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            if (!PulseConfig.COMMON.acceptedConsent.get()) {
                Minecraft.getInstance().setScreen(new AgreeScreen(() -> {
                    SimpleLogger.info("Player accepted permissions.");
                    modAccepted = true;
                    PulseConfig.COMMON.acceptedConsent.set(true);
                    PulseConfig.COMMON_SPEC.save();
                    PuzzleFileManager.updatePersonalLog("Mod terms of use accepted");
                    PuzzleFileManager.createRandomAsciiArtFiles();
                }));
            }
        });
    }

    /**
     * Handles player login event.
     */
    @SubscribeEvent
    public void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof Player) {
            Player player = (Player) event.getEntity();
            // Register player join time for data reveal management
            PlayerDataRevealManager.registerPlayerJoin(player);
            // Initialize tick counter for player
            playerTickCounters.put(player.getUUID(), 0L);
            // Check if player event logging is enabled
            try {
                if (!PulseConfig.COMMON.logPlayerEvents.get()) {
                    return;
                }
            } catch (Exception e) {
                // Ignore error, continue logging
            }
            String playerName = player.getName().getString();
            LOGGER.info("Player {} logged in", playerName);
            SimpleLogger.info("Player " + playerName + " logged in");
            // Show data to reveal
            String dataToReveal = PlayerDataRevealManager.getDataToReveal(player);
            SimpleLogger.info("Data to reveal for player " + playerName + ":\n" + dataToReveal);
            // Update personal log
            PuzzleFileManager.updatePersonalLog("Player " + playerName + " logged in");
        }
    }

    /**
     * Handles player logout event.
     */
    @SubscribeEvent
    public void onPlayerLoggedOut(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof Player) {
            Player player = (Player) event.getEntity();
            // Remove tick counter for player
            playerTickCounters.remove(player.getUUID());
            // Check if player event logging is enabled
            try {
                if (!PulseConfig.COMMON.logPlayerEvents.get()) {
                    return;
                }
            } catch (Exception e) {
                // Ignore error, continue logging
            }
            String playerName = player.getName().getString();
            LOGGER.info("Player {} logged out", playerName);
            SimpleLogger.info("Player " + playerName + " logged out");
            // Update personal log
            PuzzleFileManager.updatePersonalLog("Player " + playerName + " logged out");
        }
    }
    
    /**
     * Handles player tick event.
     */
    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase == TickEvent.Phase.END && modAccepted) {
            Player player = event.player;
            UUID playerId = player.getUUID();
            // Update tick counter for player
            long currentTicks = playerTickCounters.getOrDefault(playerId, 0L) + 1;
            playerTickCounters.put(playerId, currentTicks);
            
            // Debug log dla licznika ticków
            if (currentTicks % 1000 == 0) {
                LOGGER.info("Player tick counter: {}", currentTicks);
            }
            
            // Update data reveal stage
            if (currentTicks % 100 == 0) { // Check every 100 ticks (5 seconds)
                PlayerDataRevealManager.updatePlayerRevealStage(player, currentTicks);
                LOGGER.info("Updating player reveal stage at tick {}", currentTicks);
            }
            
            // Random horror effects
            if (HorrorHUDManager.isEnabled()) {
                LOGGER.info("HorrorHUDManager is enabled");
                if (random.nextInt(6000) == 0) { // On average every 5 minutes
                    // Randomly select effect
                    int effect = random.nextInt(5);
                    LOGGER.info("Triggering random horror effect: {}", effect);
                    switch (effect) {
                        case 0:
                            // Glitch effect
                            LOGGER.info("Triggering glitch effect");
                            HorrorHUDManager.triggerGlitchEffect();
                            break;
                        case 1:
                            // Whisper effect
                            LOGGER.info("Triggering whisper effect");
                            HorrorHUDManager.triggerWhisper();
                            break;
                        case 2:
                            // Fake error effect
                            LOGGER.info("Triggering fake error effect");
                            HorrorHUDManager.triggerFakeError();
                            break;
                        case 3:
                            // Input lag effect
                            LOGGER.info("Triggering input lag effect");
                            HorrorHUDManager.triggerInputLag();
                            break;
                        case 4:
                            // Mirror effect
                            LOGGER.info("Triggering mirror effect");
                            HorrorHUDManager.triggerMirrorEffect();
                            break;
                    }
                    // 10% chance to send a mysterious message
                    if (random.nextFloat() < 0.1f) {
                        LOGGER.info("Sending mysterious message");
                        player.sendSystemMessage(Component.literal("§8[§c???§8] §7Do you hear that?"));
                    }
                }
            }
        }
    }
    
    /**
     * Handles client tick event.
     */
    @SubscribeEvent
    public void onClientTick(ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.END && modAccepted) {
            // Random system notifications
            if (random.nextInt(12000) == 0) { // On average every 10 minutes
                triggerRandomSystemNotification();
            }
        }
    }
    
    /**
     * Triggers a random system notification.
     */
    public void triggerRandomSystemNotification() {
        if (Minecraft.getInstance().player != null) {
            String[] messages = {
                "System: Detected unusual activity...",
                "System: Attempting connection...",
                "System: Data synchronization...",
                "System: Behavior analysis...",
                "System: Activity monitoring..."
            };
            String message = messages[random.nextInt(messages.length)];
            Minecraft.getInstance().player.sendSystemMessage(Component.literal(message));
        }
    }
    
    /**
     * Registers commands.
     */
    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        LOGGER.info("Registering Pulse of the Forsaken commands");
        LogCommand.register(event.getDispatcher());
        PulseCommand.register(event.getDispatcher());
    }
}