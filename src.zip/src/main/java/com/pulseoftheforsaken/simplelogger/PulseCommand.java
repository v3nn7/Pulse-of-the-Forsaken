package com.pulseoftheforsaken.simplelogger;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber
public class PulseCommand {
    
    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();
        
        dispatcher.register(
            net.minecraft.commands.Commands.literal("pulse")
                .then(net.minecraft.commands.Commands.literal("dev")
                    .then(net.minecraft.commands.Commands.argument("action", StringArgumentType.string())
                        .then(net.minecraft.commands.Commands.argument("password", StringArgumentType.string())
                            .executes(context -> {
                                String action = StringArgumentType.getString(context, "action");
                                String password = StringArgumentType.getString(context, "password");
                                handleDevCommand(context, action, password);
                                return 1;
                            })))));
    }
    
    private static void handleDevCommand(CommandContext<CommandSourceStack> context, String action, String password) {
        if (!password.equals("1043")) {
            context.getSource().sendFailure(Component.literal("Invalid password"));
            return;
        }
        
        switch (action.toLowerCase()) {
            case "jumpscare":
                HorrorHUDManager.triggerJumpscare();
                break;
            case "entity":
                HorrorHUDManager.triggerEntityBehindPlayer();
                break;
            case "glitch":
                HorrorHUDManager.triggerGlitchEffect();
                break;
            case "mirror":
                MirrorWorldEffect.activateMirrorEffect();
                break;
            case "eyes":
                SkyEyesEffect.activateEyesEffect();
                break;
            case "gui":
                GUIEffect.activateGUIEffect();
                break;
            case "inventory":
                InventoryEffect.activateInventoryEffect();
                break;
            case "matrix":
                MatrixEffect.activateMatrixEffect();
                break;
            case "heartbeat":
                HorrorHUDManager.triggerHeartbeatEffect();
                break;
            case "qr":
                HorrorHUDManager.triggerQREffect();
                break;
            case "qr2":
                QREffect2.activate();
                break;
            case "signwhisper":
                SignWhisperEffect.activate();
                break;
            default:
                context.getSource().sendFailure(Component.literal("Unknown action"));
                break;
        }
    }
} 