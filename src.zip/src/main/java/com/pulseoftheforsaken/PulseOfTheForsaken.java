package com.pulseoftheforsaken;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import com.pulseoftheforsaken.blocks.ForsakenMirrorBlock;
import com.pulseoftheforsaken.entity.ForsakenMirrorlingEntity;
import com.pulseoftheforsaken.config.ModConfig;
import com.pulseoftheforsaken.simplelogger.util.SimpleLogger;
import com.pulseoftheforsaken.simplelogger.ArchamLanguageManager;
import com.pulseoftheforsaken.simplelogger.NotesManager;
import com.pulseoftheforsaken.simplelogger.config.PulseConfig;
import net.minecraft.client.renderer.entity.EntityRenderers;
import com.pulseoftheforsaken.client.render.ForsakenMirrorlingRenderer;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.pulseoftheforsaken.simplelogger.config.LanguageConfig;

@Mod(PulseOfTheForsaken.MOD_ID)
public class PulseOfTheForsaken {
    public static final String MOD_ID = "pulseoftheforsaken";
    private static final Logger LOGGER = LogManager.getLogger();
    
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MOD_ID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MOD_ID);
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MOD_ID);

    public static final RegistryObject<Block> FORSAKEN_MIRROR = BLOCKS.register("forsaken_mirror",
        ForsakenMirrorBlock::new);
    public static final RegistryObject<Item> FORSAKEN_MIRROR_ITEM = ITEMS.register("forsaken_mirror",
        () -> new BlockItem(FORSAKEN_MIRROR.get(), new Item.Properties()));
    public static final RegistryObject<EntityType<ForsakenMirrorlingEntity>> FORSAKEN_MIRRORLING = ENTITIES.register(
        "forsaken_mirrorling",
        () -> EntityType.Builder.<ForsakenMirrorlingEntity>of(ForsakenMirrorlingEntity::new, MobCategory.MONSTER)
            .sized(0.6F, 1.8F)
            .build(new ResourceLocation(MOD_ID, "forsaken_mirrorling").toString()));

    public PulseOfTheForsaken() {
        LOGGER.info("Initializing Pulse of the Forsaken mod");
        
        try {
            IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
            
            // Rejestracja konfiguracji
            LOGGER.info("Initializing mod config");
            ModConfig.init();
            PulseConfig.register();
            LanguageConfig.register();
            
            // Rejestracja bloków i przedmiotów
            LOGGER.info("Registering blocks and items");
            BLOCKS.register(modEventBus);
            ITEMS.register(modEventBus);
            ENTITIES.register(modEventBus);
            
            // Rejestracja nasłuchiwaczy zdarzeń
            LOGGER.info("Registering event listeners");
            modEventBus.addListener(this::setup);
            modEventBus.addListener(this::clientSetup);
            
            MinecraftForge.EVENT_BUS.register(this);
            MinecraftForge.EVENT_BUS.register(ArchamLanguageManager.class);
            MinecraftForge.EVENT_BUS.register(NotesManager.class);
            
            LOGGER.info("Mod initialization completed successfully");
        } catch (Exception e) {
            LOGGER.error("Failed to initialize mod: {}", e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Critical error during mod initialization", e);
        }
    }

    @SubscribeEvent
    public void setup(FMLCommonSetupEvent event) {
        event.enqueueWork(() -> {
            try {
                LOGGER.info("Starting server-side initialization");
                
                // Inicjalizacja po stronie serwera
                NotesManager.initialize();
                SimpleLogger.init();
                
                LOGGER.info("Server-side initialization completed");
            } catch (Exception e) {
                LOGGER.error("Error during server initialization: {}", e.getMessage());
                e.printStackTrace();
                throw new RuntimeException("Failed to initialize server components", e);
            }
        });
    }

    @SubscribeEvent
    public void clientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            try {
                LOGGER.info("Starting client-side initialization");
                
                // Inicjalizacja po stronie klienta
                EntityRenderers.register(FORSAKEN_MIRRORLING.get(), ForsakenMirrorlingRenderer::new);
                ArchamLanguageManager.initialize();
                
                LOGGER.info("Client-side initialization completed");
            } catch (Exception e) {
                LOGGER.error("Error during client initialization: {}", e.getMessage());
                e.printStackTrace();
                throw new RuntimeException("Failed to initialize client components", e);
            }
        });
    }
}