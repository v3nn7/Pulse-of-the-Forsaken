package com.pulseoftheforsaken.registry;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import com.pulseoftheforsaken.PulseOfTheForsaken;
import com.pulseoftheforsaken.entity.ForsakenMirrorlingEntity;
import com.pulseoftheforsaken.entity.DevGlitchEntity;

public class ModEntityTypes {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, PulseOfTheForsaken.MOD_ID);

    public static final RegistryObject<EntityType<ForsakenMirrorlingEntity>> FORSAKEN_MIRRORLING = ENTITY_TYPES.register("forsaken_mirrorling",
        () -> EntityType.Builder.<ForsakenMirrorlingEntity>of(ForsakenMirrorlingEntity::new, MobCategory.MONSTER)
            .sized(0.6F, 1.8F)
            .build("forsaken_mirrorling"));

    public static final RegistryObject<EntityType<DevGlitchEntity>> DEV_GLITCH = ENTITY_TYPES.register("dev_glitch",
        () -> EntityType.Builder.<DevGlitchEntity>of(DevGlitchEntity::new, MobCategory.MISC)
            .sized(0.6F, 1.8F)
            .build("dev_glitch"));
} 