package com.pulseoftheforsaken.blocks;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.phys.AABB;
import com.pulseoftheforsaken.entity.ForsakenMirrorlingEntity;
import com.pulseoftheforsaken.client.gui.GlitchEffectScreen;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraft.world.phys.Vec3;
import com.pulseoftheforsaken.sound.SoundManager;
import com.pulseoftheforsaken.registry.ModEntityTypes;

public class ForsakenMirrorBlock extends Block {
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;
    private static final VoxelShape SHAPE = Block.box(0.0D, 0.0D, 0.0D, 16.0D, 16.0D, 1.0D);

    public ForsakenMirrorBlock() {
        super(BlockBehaviour.Properties.of()
            .mapColor(MapColor.METAL)
            .strength(3.0F, 6.0F)
            .requiresCorrectToolForDrops()
            .noOcclusion());
        this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
    }

    public VoxelShape getShape(BlockState state, Level level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, 
                               InteractionHand hand, BlockHitResult hit) {
        if (!level.isClientSide && isPlayerLookingAtBlock(player, pos)) {
            triggerMirrorEffect(level, pos, player);
            return InteractionResult.SUCCESS;
        }
        return InteractionResult.PASS;
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock())) {
            level.getEntitiesOfClass(ForsakenMirrorlingEntity.class, 
                new AABB(pos.getX() - 16, pos.getY() - 16, pos.getZ() - 16,
                        pos.getX() + 16, pos.getY() + 16, pos.getZ() + 16))
                .forEach(entity -> entity.discard());
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    private boolean isPlayerLookingAtBlock(Player player, BlockPos pos) {
        Vec3 playerPos = player.getEyePosition();
        Vec3 blockPos = Vec3.atCenterOf(pos);
        double distance = playerPos.distanceTo(blockPos);
        
        if (distance <= 16.0D) {
            Vec3 lookVec = player.getLookAngle();
            Vec3 toBlock = blockPos.subtract(playerPos).normalize();
            double dot = lookVec.dot(toBlock);
            return dot > 0.9D;
        }
        return false;
    }

    @OnlyIn(Dist.CLIENT)
    private void triggerMirrorEffect(Level level, BlockPos pos, Player player) {
        if (!level.isClientSide) {
            ForsakenMirrorlingEntity mirrorling = new ForsakenMirrorlingEntity(ModEntityTypes.FORSAKEN_MIRRORLING.get(), level);
            mirrorling.setPos(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
            level.addFreshEntity(mirrorling);
            SoundManager.playMirrorBreakSound(player);
        }
    }
} 