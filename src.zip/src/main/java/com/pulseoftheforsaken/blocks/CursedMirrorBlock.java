package com.pulseoftheforsaken.blocks;

import com.pulseoftheforsaken.client.gui.GlitchEffectScreen;
import com.pulseoftheforsaken.sound.SoundManager;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.Level;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class CursedMirrorBlock extends Block {
    private static final int MAX_LOOK_TIME = 100; // 5 sekund
    private int lookTimer = 0;
    private boolean isLooking = false;

    public CursedMirrorBlock(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, 
                              Player player, InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) {
            if (!isLooking) {
                isLooking = true;
                lookTimer = 0;
            }
        }
        return InteractionResult.SUCCESS;
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        if (!level.isClientSide) {
            SoundManager.playMirrorBreakSound(player);
            player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 200, 1));
            player.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 200, 1));
        }
        super.playerWillDestroy(level, pos, state, player);
    }

    @OnlyIn(Dist.CLIENT)
    public void tick() {
        if (isLooking) {
            lookTimer++;
            if (lookTimer >= MAX_LOOK_TIME) {
                triggerJumpscare();
                isLooking = false;
                lookTimer = 0;
            }
        }
    }

    @OnlyIn(Dist.CLIENT)
    private void triggerJumpscare() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            // Odtwórz dźwięk
            SoundManager.playMirrorBreakSound(mc.player);
            
            // Dodaj efekty
            mc.player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 200, 1));
            mc.player.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 200, 1));
            
            // Pokaż ekran glitcha
            mc.setScreen(new GlitchEffectScreen());
            
            // Zniszcz blok
            mc.level.destroyBlock(mc.player.blockPosition(), false);
        }
    }
} 