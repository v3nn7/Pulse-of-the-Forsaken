package com.pulseoftheforsaken.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import com.pulseoftheforsaken.sound.SoundManager;

public class ForsakenMirrorlingEntity extends PathfinderMob {
    private boolean isArchamVariant;
    private int attackCooldown;

    public ForsakenMirrorlingEntity(EntityType<? extends PathfinderMob> entityType, Level level) {
        super(entityType, level);
        this.isArchamVariant = Math.random() < 0.1;
        this.attackCooldown = 0;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
            .add(Attributes.MAX_HEALTH, 20.0D)
            .add(Attributes.MOVEMENT_SPEED, 0.3D)
            .add(Attributes.ATTACK_DAMAGE, 3.0D)
            .add(Attributes.FOLLOW_RANGE, 32.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0D, false));
        this.goalSelector.addGoal(3, new RandomStrollGoal(this, 1.0D));
        this.goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(5, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public void tick() {
        super.tick();

        if (this.attackCooldown > 0) {
            this.attackCooldown--;
        }

        if (this.isArchamVariant) {
            if (this.random.nextInt(200) == 0) {
                Player nearestPlayer = this.level().getNearestPlayer(this, 16.0D);
                if (nearestPlayer != null) {
                    this.triggerJumpScare(nearestPlayer);
                }
            }

            if (this.random.nextInt(600) == 0) {
                Player target = this.level().getNearestPlayer(this, 32.0D);
                if (target != null) {
                    double x = target.getX() + (this.random.nextDouble() - 0.5D) * 8.0D;
                    double z = target.getZ() + (this.random.nextDouble() - 0.5D) * 8.0D;
                    this.teleportTo(x, this.getY(), z);
                    SoundManager.playGlitchSound(target);
                }
            }
        }

        if (this.isArchamVariant && this.tickCount % 20 == 0) {
            this.setDeltaMovement(
                this.getDeltaMovement().x + (this.random.nextDouble() - 0.5D) * 0.1D,
                this.getDeltaMovement().y,
                this.getDeltaMovement().z + (this.random.nextDouble() - 0.5D) * 0.1D
            );
        }
    }

    public boolean isArchamVariant() {
        return this.isArchamVariant;
    }

    public void setArchamVariant(boolean isArcham) {
        this.isArchamVariant = isArcham;
        if (isArcham) {
            this.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, Integer.MAX_VALUE, 0, false, false));
            this.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, Integer.MAX_VALUE, 1, false, false));
        }
    }

    private void triggerJumpScare(Player player) {
        if (this.attackCooldown <= 0) {
            this.attackCooldown = 100;
            player.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 60, 0));
            player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 100, 0));
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 1));
            SoundManager.playMirrorBreakSound(player);
            SoundManager.playGlitchSound(player);
        }
    }
} 