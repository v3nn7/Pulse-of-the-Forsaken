package com.pulseoftheforsaken.entity;

import net.minecraft.world.entity.player.Player;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;
import net.minecraft.world.level.Level;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import com.pulseoftheforsaken.config.ModConfig;
import net.minecraft.world.entity.EntityType;
import net.minecraft.core.BlockPos;
import net.minecraftforge.registries.ForgeRegistries;
import com.pulseoftheforsaken.PulseOfTheForsaken;

@Mod.EventBusSubscriber
public class ArchamMobManager {
    private static boolean isArchamMobUnlocked = false;

    public static boolean isArchamMobUnlocked() {
        return isArchamMobUnlocked && ModConfig.isArchamLanguageEnabled();
    }

    public static boolean tryUnlockArchamMob(String code, Player player) {
        if (code.equals(ModConfig.ARCHAM_UNLOCK_CODE.get())) {
            isArchamMobUnlocked = true;
            player.sendSystemMessage(Component.literal(
                ChatFormatting.GREEN + "Archam entity unlocked!"));
            return true;
        }
        return false;
    }

    @SubscribeEvent
    public static void onPlayerJoin(PlayerEvent.PlayerLoggedInEvent event) {
        if (isArchamMobUnlocked()) {
            event.getEntity().sendSystemMessage(Component.literal(
                ChatFormatting.GREEN + "Archam entity is unlocked!"));
        }
    }

    public static void spawnArchamMob(Level level, BlockPos pos) {
        if (!level.isClientSide) {
            EntityType<?> entityType = ForgeRegistries.ENTITY_TYPES.getValue(
                new ResourceLocation(PulseOfTheForsaken.MOD_ID, "forsaken_mirrorling")
            );
            
            if (entityType != null) {
                ForsakenMirrorlingEntity entity = (ForsakenMirrorlingEntity) entityType.create(level);
                if (entity != null) {
                    entity.setPos(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
                    entity.setArchamVariant(true);
                    level.addFreshEntity(entity);
                }
            }
        }
    }
} 