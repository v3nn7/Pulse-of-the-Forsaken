package com.pulseoftheforsaken.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import com.pulseoftheforsaken.PulseOfTheForsaken;

public class ForsakenMirrorlingRenderer extends HumanoidMobRenderer<ForsakenMirrorlingEntity, PlayerModel<ForsakenMirrorlingEntity>> {
    private static final ResourceLocation NORMAL_TEXTURE = 
        new ResourceLocation(PulseOfTheForsaken.MOD_ID, "textures/entity/forsaken_mirrorling.png");
    private static final ResourceLocation ARCHAM_TEXTURE = 
        new ResourceLocation(PulseOfTheForsaken.MOD_ID, "textures/entity/archam_mirrorling.png");
    private float alpha = 1.0f;

    public ForsakenMirrorlingRenderer(EntityRendererProvider.Context context) {
        super(context, new PlayerModel<>(context.bakeLayer(ModelLayers.PLAYER), false), 0.5f);
        this.addLayer(new HumanoidArmorLayer<>(this,
            new PlayerModel<>(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR), true),
            new PlayerModel<>(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR), true),
            context.getModelManager()));
        this.addLayer(new ItemInHandLayer<>(this, context.getItemInHandRenderer()));
        this.addLayer(new ForsakenMirrorlingEyesLayer<>(this));
    }

    @Override
    public ResourceLocation getTextureLocation(ForsakenMirrorlingEntity entity) {
        return entity.isArchamVariant() ? ARCHAM_TEXTURE : NORMAL_TEXTURE;
    }

    @Override
    public void render(ForsakenMirrorlingEntity entity, float entityYaw, float partialTicks,
                      PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
        if (entity.isArchamVariant()) {
            poseStack.pushPose();
            float scale = 1.2f + (float)Math.sin(entity.tickCount * 0.1f) * 0.05f;
            poseStack.scale(scale, scale, scale);
            
            float shake = (float)Math.sin(entity.tickCount * 0.2f) * 0.02f;
            poseStack.translate(shake, 0, shake);
            
            float alpha = 0.7f + (float)Math.sin(entity.tickCount * 0.1f) * 0.3f;
            this.alpha = alpha;
            
            super.render(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
            poseStack.popPose();
        } else {
            super.render(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
        }
    }

    @Override
    protected void scale(ForsakenMirrorlingEntity entity, PoseStack poseStack, float partialTickTime) {
        float scale = entity.isArchamVariant() ? 1.2f : 1.0f;
        poseStack.scale(scale, scale, scale);
    }
} 