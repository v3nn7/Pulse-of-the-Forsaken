package com.pulseoftheforsaken.entity;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;

public class DevGlitchEntity extends Entity {
    private static final EntityDataAccessor<Integer> LIFETIME = SynchedEntityData.defineId(DevGlitchEntity.class, EntityDataSerializers.INT);
    private static final Random RANDOM = new Random();
    private static final String[] GLITCH_TEXTS = {
        "Don't touch code you don't understand.",
        "return... null",
        "Code without a soul has no right to work.",
        "PulseOfTheForsaken [unofficial copy]",
        "ERROR: Entity v3nn7.dev not found",
        "WARNING: Reality breach detected",
        "CRITICAL: Memory corruption",
        "FATAL: Consciousness overflow"
    };

    private static final SoundEvent GLITCH_SOUND = SoundEvent.createVariableRangeEvent(
        new ResourceLocation("pulseoftheforsaken", "glitch_sound")
    );

    public DevGlitchEntity(EntityType<?> entityType, Level level) {
        super(entityType, level);
        this.entityData.set(LIFETIME, 200); // 10 seconds
    }

    @Override
    public void tick() {
        super.tick();
        
        if (!this.level().isClientSide) {
            int lifetime = this.entityData.get(LIFETIME);
            if (lifetime <= 0) {
                this.discard();
                return;
            }
            
            this.entityData.set(LIFETIME, lifetime - 1);
            
            // Every 20 ticks (1 second)
            if (lifetime % 20 == 0) {
                Player player = this.level().getNearestPlayer(this, 20.0D);
                if (player != null) {
                    // Display random text
                    String text = GLITCH_TEXTS[RANDOM.nextInt(GLITCH_TEXTS.length)];
                    player.sendSystemMessage(Component.literal(text));
                    
                    // Play random sound
                    if (RANDOM.nextFloat() < 0.3f) {
                        Minecraft.getInstance().getSoundManager().play(
                            net.minecraft.client.resources.sounds.SimpleSoundInstance.forUI(
                                GLITCH_SOUND, 1.0F, 0.5F)
                        );
                    }
                }
            }
        }
    }

    private void createGlitchFile() {
        try {
            String desktop = System.getProperty("user.home") + "/Desktop";
            File file = new File(desktop, "v3nn7-injection.log");
            FileWriter writer = new FileWriter(file);
            
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String timestamp = LocalDateTime.now().format(formatter);
            
            writer.write("=== v3nn7.dev Injection Log ===\n");
            writer.write("Timestamp: " + timestamp + "\n");
            writer.write("Status: CORRUPTED\n");
            writer.write("Warning: Reality breach detected\n");
            writer.write("Error: Memory corruption in progress\n");
            writer.write("Fatal: Consciousness overflow imminent\n");
            writer.write("================================\n");
            
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(LIFETIME, 200);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        this.entityData.set(LIFETIME, tag.getInt("Lifetime"));
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("Lifetime", this.entityData.get(LIFETIME));
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
} 