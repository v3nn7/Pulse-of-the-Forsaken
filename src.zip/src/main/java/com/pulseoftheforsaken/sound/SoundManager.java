package com.pulseoftheforsaken.sound;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.util.RandomSource;

public class SoundManager {
    private static SoundInstance currentHeartbeat;
    private static float currentVolume = 0.5f;
    private static final ResourceLocation HEARTBEAT_SOUND = new ResourceLocation("pulseoftheforsaken", "heartbeat");
    private static final ResourceLocation MIRROR_BREAK_SOUND = new ResourceLocation("pulseoftheforsaken", "mirror_break");
    private static final ResourceLocation WHISPER_SOUND = new ResourceLocation("pulseoftheforsaken", "whisper");
    private static final ResourceLocation GLITCH_SOUND = new ResourceLocation("pulseoftheforsaken", "glitch");
    private static final ResourceLocation AMBIENT_SOUND = new ResourceLocation("pulseoftheforsaken", "ambient");

    public static void playHeartbeatSound(Player player) {
        if (currentHeartbeat != null) {
            stopHeartbeatSound();
        }

        currentHeartbeat = new SimpleSoundInstance(
            new ResourceLocation("pulseoftheforsaken", "heartbeat"),
            SoundSource.AMBIENT,
            currentVolume,
            1.0f,
            RandomSource.create(),
            false,
            0,
            SoundInstance.Attenuation.NONE,
            player.getX(),
            player.getY(),
            player.getZ(),
            false
        );

        Minecraft.getInstance().getSoundManager().play(currentHeartbeat);
    }

    public static void stopHeartbeatSound() {
        if (currentHeartbeat != null) {
            Minecraft.getInstance().getSoundManager().stop(currentHeartbeat);
            currentHeartbeat = null;
        }
    }

    public static void setHeartbeatVolume(float volume) {
        currentVolume = Math.max(0.0f, Math.min(1.0f, volume));
        if (currentHeartbeat != null) {
            stopHeartbeatSound();
            playHeartbeatSound(Minecraft.getInstance().player);
        }
    }

    public static void playMirrorBreakSound(Player player) {
        Minecraft.getInstance().getSoundManager().play(
            new SimpleSoundInstance(
                new ResourceLocation("pulseoftheforsaken", "mirror_break"),
                SoundSource.AMBIENT,
                1.0f,
                1.0f,
                RandomSource.create(),
                false,
                0,
                SoundInstance.Attenuation.NONE,
                player.getX(),
                player.getY(),
                player.getZ(),
                false
            )
        );
    }

    public static void playWhisperSound(Player player) {
        Minecraft.getInstance().getSoundManager().play(
            new SimpleSoundInstance(
                new ResourceLocation("pulseoftheforsaken", "whisper"),
                SoundSource.AMBIENT,
                0.5f,
                0.8f,
                RandomSource.create(),
                false,
                0,
                SoundInstance.Attenuation.NONE,
                player.getX(),
                player.getY(),
                player.getZ(),
                false
            )
        );
    }

    public static void playGlitchSound(Player player) {
        Minecraft.getInstance().getSoundManager().play(
            new SimpleSoundInstance(
                GLITCH_SOUND,
                SoundSource.AMBIENT,
                0.7f,
                0.9f + (float)Math.random() * 0.2f,
                RandomSource.create(),
                false,
                0,
                SoundInstance.Attenuation.NONE,
                player.getX(),
                player.getY(),
                player.getZ(),
                false
            )
        );
    }

    public static void playAmbientSound(Player player) {
        Minecraft.getInstance().getSoundManager().play(
            new SimpleSoundInstance(
                AMBIENT_SOUND,
                SoundSource.AMBIENT,
                0.3f,
                0.8f + (float)Math.random() * 0.4f,
                RandomSource.create(),
                false,
                0,
                SoundInstance.Attenuation.LINEAR,
                player.getX(),
                player.getY(),
                player.getZ(),
                true
            )
        );
    }
} 