package com.pulseoftheforsaken.client.render;

import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.resources.ResourceLocation;
import com.pulseoftheforsaken.PulseOfTheForsaken;
import com.pulseoftheforsaken.entity.ForsakenMirrorlingEntity;

public class ForsakenMirrorlingEyesLayer<T extends ForsakenMirrorlingEntity> extends EyesLayer<T, PlayerModel<T>> {
    private static final ResourceLocation NORMAL_EYES_TEXTURE = new ResourceLocation(PulseOfTheForsaken.MOD_ID, "textures/entity/forsaken_mirrorling_eyes.png");
    private static final ResourceLocation ARCHAM_EYES_TEXTURE = new ResourceLocation(PulseOfTheForsaken.MOD_ID, "textures/entity/forsaken_mirrorling_archam_eyes.png");

    public ForsakenMirrorlingEyesLayer(RenderLayerParent<T, PlayerModel<T>> renderer) {
        super(renderer);
    }

    @Override
    public RenderType renderType() {
        return RenderType.eyes(NORMAL_EYES_TEXTURE);
    }

    @Override
    public void render(com.mojang.blaze3d.vertex.PoseStack poseStack, net.minecraft.client.renderer.MultiBufferSource buffer, 
                      int packedLight, T entity, float limbSwing, float limbSwingAmount, 
                      float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
        if (entity.isArchamVariant()) {
            super.render(poseStack, buffer, packedLight, entity, limbSwing, limbSwingAmount, 
                        partialTicks, ageInTicks, netHeadYaw, headPitch);
        }
    }
} 