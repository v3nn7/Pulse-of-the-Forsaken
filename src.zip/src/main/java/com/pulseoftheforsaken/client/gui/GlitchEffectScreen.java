package com.pulseoftheforsaken.client.gui;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.util.RandomSource;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.ChatFormatting;

import java.util.Random;

public class GlitchEffectScreen extends Screen {
    private static final Random RANDOM = new Random();
    private int tickCount = 0;
    private static final int MAX_TICKS = 200; // 10 seconds

    public GlitchEffectScreen() {
        super(Component.empty());
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
        this.renderBackground(graphics);
        
        Font font = Minecraft.getInstance().font;
        int width = this.width;
        int height = this.height;

        // Glitch effect
        for (int i = 0; i < 20; i++) {
            String text = generateGlitchText();
            int x = RANDOM.nextInt(width);
            int y = RANDOM.nextInt(height);
            
            Style style = Style.EMPTY
                .withColor(ChatFormatting.RED)
                .withObfuscated(true);
            
            graphics.drawString(font, Component.literal(text).withStyle(style), x, y, 0xFFFFFF);
        }

        // Main text
        String mainText = "SYSTEM ERROR: CORRUPTION DETECTED";
        int textWidth = font.width(mainText);
        int textX = (width - textWidth) / 2;
        int textY = height / 2;

        graphics.drawString(font, mainText, textX, textY, 0xFF0000);

        super.render(graphics, mouseX, mouseY, partialTicks);
    }

    private String generateGlitchText() {
        StringBuilder text = new StringBuilder();
        int length = RANDOM.nextInt(20) + 10;
        for (int i = 0; i < length; i++) {
            text.append((char) (RANDOM.nextInt(26) + 'A'));
        }
        return text.toString();
    }

    @Override
    public void tick() {
        super.tick();
        tickCount++;
        if (tickCount >= MAX_TICKS) {
            this.onClose();
        }
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
} 