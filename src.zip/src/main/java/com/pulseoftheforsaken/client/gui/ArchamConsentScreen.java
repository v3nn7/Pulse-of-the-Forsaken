package com.pulseoftheforsaken.client.gui;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.ChatFormatting;
import com.pulseoftheforsaken.simplelogger.ArchamLanguageManager;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ArchamConsentScreen extends Screen {
    private static final Logger LOGGER = LogManager.getLogger();
    private static final ResourceLocation BACKGROUND = new ResourceLocation("pulseoftheforsaken", "textures/gui/archam_consent.png");
    private static final int BUTTON_WIDTH = 200;
    private static final int BUTTON_HEIGHT = 20;
    private static final int BUTTON_SPACING = 5;

    public ArchamConsentScreen() {
        super(Component.translatable("screen.pulseoftheforsaken.archam_consent"));
        LOGGER.info("ArchamConsentScreen created");
    }

    @Override
    protected void init() {
        try {
            super.init();
            int centerX = this.width / 2;
            int centerY = this.height / 2;

            // Accept button
            this.addRenderableWidget(Button.builder(Component.translatable("button.pulseoftheforsaken.accept"), 
                button -> {
                    try {
                        LOGGER.info("Accept button clicked");
                        ArchamLanguageManager.unlockArchamLanguage();
                        this.onClose();
                    } catch (Exception e) {
                        LOGGER.error("Error in accept button handler: {}", e.getMessage());
                        e.printStackTrace();
                    }
                })
                .bounds(centerX - BUTTON_WIDTH / 2, centerY + 80, BUTTON_WIDTH, BUTTON_HEIGHT)
                .build());

            // Decline button
            this.addRenderableWidget(Button.builder(Component.translatable("button.pulseoftheforsaken.decline"), 
                button -> {
                    try {
                        LOGGER.info("Decline button clicked");
                        this.onClose();
                    } catch (Exception e) {
                        LOGGER.error("Error in decline button handler: {}", e.getMessage());
                        e.printStackTrace();
                    }
                })
                .bounds(centerX - BUTTON_WIDTH / 2, centerY + 80 + BUTTON_HEIGHT + BUTTON_SPACING, BUTTON_WIDTH, BUTTON_HEIGHT)
                .build());
                
            LOGGER.info("ArchamConsentScreen initialized successfully");
        } catch (Exception e) {
            LOGGER.error("Error initializing ArchamConsentScreen: {}", e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
        try {
            this.renderBackground(graphics);
            
            int centerX = this.width / 2;
            int centerY = this.height / 2;

            // Title
            graphics.drawCenteredString(this.font, this.title.copy().withStyle(ChatFormatting.BOLD), centerX, centerY - 80, 0xFFFFFF);
            
            // Warning text
            MutableComponent warning = Component.translatable("text.pulseoftheforsaken.archam_warning")
                .withStyle(ChatFormatting.RED, ChatFormatting.BOLD);
            graphics.drawCenteredString(this.font, warning, centerX, centerY - 60, 0xFFFFFF);

            // Warning details
            String[] warningKeys = {
                "text.pulseoftheforsaken.warning1",
                "text.pulseoftheforsaken.warning2",
                "text.pulseoftheforsaken.warning3",
                "text.pulseoftheforsaken.warning4"
            };

            for (int i = 0; i < warningKeys.length; i++) {
                MutableComponent text = Component.translatable(warningKeys[i])
                    .withStyle(ChatFormatting.GRAY);
                graphics.drawCenteredString(this.font, text, centerX, centerY - 40 + (i * 12), 0xFFFFFF);
            }

            // Social links
            MutableComponent socialLinks = Component.translatable("text.pulseoftheforsaken.social_links")
                .withStyle(ChatFormatting.GOLD);
            graphics.drawCenteredString(this.font, socialLinks, centerX, centerY + 120, 0xFFFFFF);

            MutableComponent discord = Component.translatable("text.pulseoftheforsaken.discord")
                .withStyle(ChatFormatting.BLUE);
            graphics.drawCenteredString(this.font, discord, centerX, centerY + 132, 0xFFFFFF);

            MutableComponent guilded = Component.translatable("text.pulseoftheforsaken.guilded")
                .withStyle(ChatFormatting.DARK_PURPLE);
            graphics.drawCenteredString(this.font, guilded, centerX, centerY + 144, 0xFFFFFF);

            super.render(graphics, mouseX, mouseY, partialTicks);
        } catch (Exception e) {
            LOGGER.error("Error rendering ArchamConsentScreen: {}", e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
} 