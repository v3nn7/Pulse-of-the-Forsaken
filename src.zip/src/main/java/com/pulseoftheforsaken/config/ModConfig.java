package com.pulseoftheforsaken.config;

import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.config.ModConfig.Type;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ModConfig {
    private static final Logger LOGGER = LogManager.getLogger();
    public static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();
    public static final ForgeConfigSpec.BooleanValue ARCHAM_LANGUAGE_ENABLED;
    public static final ForgeConfigSpec.ConfigValue<String> ARCHAM_UNLOCK_CODE;
    public static final ForgeConfigSpec SPEC;

    static {
        BUILDER.push("Archam Language Settings");
        ARCHAM_LANGUAGE_ENABLED = BUILDER
            .comment("Whether the Archam language is enabled")
            .define("archamLanguageEnabled", false);
        ARCHAM_UNLOCK_CODE = BUILDER
            .comment("The code required to unlock the Archam language")
            .define("archamUnlockCode", "ARCHAM");
        BUILDER.pop();
        SPEC = BUILDER.build();
    }

    public static void init() {
        try {
            ModLoadingContext.get().registerConfig(Type.COMMON, SPEC, "pulseoftheforsaken-common.toml");
            LOGGER.info("ModConfig initialized successfully");
        } catch (Exception e) {
            LOGGER.error("Failed to initialize ModConfig: {}", e.getMessage());
            e.printStackTrace();
        }
    }

    public static boolean isArchamLanguageEnabled() {
        return ARCHAM_LANGUAGE_ENABLED.get();
    }

    public static void setArchamLanguageEnabled(boolean enabled) {
        try {
            ARCHAM_LANGUAGE_ENABLED.set(enabled);
            save();
            LOGGER.info("Archam language enabled set to: {}", enabled);
        } catch (Exception e) {
            LOGGER.error("Failed to set Archam language enabled: {}", e.getMessage());
            e.printStackTrace();
        }
    }

    public static String getArchamUnlockCode() {
        return ARCHAM_UNLOCK_CODE.get();
    }

    public static void save() {
        try {
            SPEC.save();
            LOGGER.info("Configuration saved successfully");
        } catch (Exception e) {
            LOGGER.error("Failed to save configuration: {}", e.getMessage());
            e.printStackTrace();
        }
    }
} 